package com.example.villagersense.lumberjack.ai;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.SaplingBlock;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.village.VillagerProfession;

import java.util.*;

public class ChopTreeGoal extends Goal {
    private final VillagerEntity villager;
    private final SimpleInventory inventory;
    private BlockPos treeBase;
    private boolean treeBroken;

    private static final int SEARCH_RADIUS = 10;

    public ChopTreeGoal(VillagerEntity villager, SimpleInventory inventory) {
        this.villager = villager;
        this.inventory = inventory;
        this.setControls(EnumSet.of(Control.MOVE, Control.LOOK));
    }

    @Override
    public boolean canStart() {
        var prof = villager.getVillagerData().getProfession();
        if (!prof.equals(VillagerProfession.NONE) && !prof.equals(VillagerProfession.BUTCHER)) {
            return false;
        }
        if (villager.isBaby()) return false;
        if (villager.getRandom().nextInt(200) != 0) return false;

        BlockPos tree = findNearbyTree();
        if (tree != null) {
            this.treeBase = tree;
            this.treeBroken = false;
            return true;
        }
        return false;
    }

    @Override
    public void start() {
        villager.getNavigation().startMovingTo(treeBase.getX(), treeBase.getY(), treeBase.getZ(), 0.6);
    }

    @Override
    public boolean shouldContinue() {
        if (treeBase == null || treeBroken) return false;
        BlockState state = villager.getWorld().getBlockState(treeBase);
        return isLog(state) || isLeaves(state);
    }

    @Override
    public void stop() {
        treeBase = null;
        treeBroken = false;
    }

    @Override
    public void tick() {
        if (treeBase == null || treeBroken) return;

        double distance = villager.getBlockPos().getSquaredDistance(treeBase);
        if (distance <= 9.0) {
            villager.getNavigation().stop();
            breakTree();
            treeBroken = true;
            pickupItems();
            replantSapling();
            stop();
        } else {
            villager.getNavigation().startMovingTo(treeBase.getX(), treeBase.getY(), treeBase.getZ(), 0.6);
        }
    }

    private void breakTree() {
        List<BlockPos> blocks = collectTreeBlocks(treeBase);
        if (villager.getWorld() instanceof ServerWorld world) {
            for (BlockPos pos : blocks) {
                world.breakBlock(pos, true, villager);
            }
            world.playSound(null, treeBase, SoundEvents.BLOCK_WOOD_BREAK,
                    SoundCategory.NEUTRAL, 1.0F, 0.8F + world.random.nextFloat() * 0.4F);
        }
    }

    private void pickupItems() {
        List<ItemEntity> items = villager.getWorld().getEntitiesByClass(ItemEntity.class,
                villager.getBoundingBox().expand(5.0), item -> {
                    ItemStack stack = item.getStack();
                    return isWoodOrSapling(stack.getItem());
                });
        for (ItemEntity item : items) {
            ItemStack stack = item.getStack();
            for (int i = 0; i < inventory.size(); i++) {
                ItemStack invStack = inventory.getStack(i);
                if (invStack.isEmpty()) {
                    inventory.setStack(i, stack);
                    item.discard();
                    break;
                } else if (ItemStack.areItemsEqual(invStack, stack) && invStack.getCount() < invStack.getMaxCount()) {
                    int transfer = Math.min(stack.getCount(), invStack.getMaxCount() - invStack.getCount());
                    stack.decrement(transfer);
                    invStack.increment(transfer);
                    if (stack.isEmpty()) {
                        item.discard();
                        break;
                    }
                }
            }
            if (!item.isAlive()) {
                villager.getWorld().playSound(null, villager.getBlockPos(),
                        SoundEvents.ENTITY_ITEM_PICKUP, SoundCategory.NEUTRAL, 0.2F,
                        (villager.getRandom().nextFloat() - villager.getRandom().nextFloat()) * 0.7F + 1.0F);
            }
        }
    }

    private void replantSapling() {
        ItemStack saplingToPlant = null;
        int saplingSlot = -1;
        for (int i = 0; i < inventory.size(); i++) {
            ItemStack stack = inventory.getStack(i);
            if (stack.getItem() instanceof BlockItem blockItem && blockItem.getBlock() instanceof SaplingBlock) {
                saplingToPlant = stack;
                saplingSlot = i;
                break;
            }
        }
        if (saplingToPlant != null) {
            BlockPos plantPos = treeBase;
            BlockState state = villager.getWorld().getBlockState(plantPos);
            if (state.isAir() || state.isReplaceable()) {
                BlockState saplingState = ((BlockItem) saplingToPlant.getItem()).getBlock().getDefaultState();
                villager.getWorld().setBlockState(plantPos, saplingState);
                inventory.setStack(saplingSlot, ItemStack.EMPTY);
            }
        }
    }

    private List<BlockPos> collectTreeBlocks(BlockPos base) {
        Set<BlockPos> visited = new HashSet<>();
        Queue<BlockPos> queue = new LinkedList<>();
        queue.add(base);
        visited.add(base);
        while (!queue.isEmpty()) {
            BlockPos current = queue.poll();
            for (BlockPos offset : new BlockPos[]{
                    current.up(), current.down(),
                    current.north(), current.south(),
                    current.east(), current.west()
            }) {
                if (visited.contains(offset)) continue;
                BlockState state = villager.getWorld().getBlockState(offset);
                if (isLog(state) || isLeaves(state)) {
                    visited.add(offset);
                    queue.add(offset);
                }
            }
        }
        return new ArrayList<>(visited);
    }

    private BlockPos findNearbyTree() {
        BlockPos.Mutable pos = new BlockPos.Mutable();
        for (int x = -SEARCH_RADIUS; x <= SEARCH_RADIUS; x++) {
            for (int y = -3; y <= 3; y++) {
                for (int z = -SEARCH_RADIUS; z <= SEARCH_RADIUS; z++) {
                    pos.set(villager.getBlockX() + x, villager.getBlockY() + y, villager.getBlockZ() + z);
                    BlockState state = villager.getWorld().getBlockState(pos);
                    if (isLog(state) && isTreeBase(pos) && isPartOfTree(pos)) {
                        return pos.toImmutable();
                    }
                }
            }
        }
        return null;
    }

    private boolean isLog(BlockState state) {
        return state.isOf(Blocks.OAK_LOG) || state.isOf(Blocks.BIRCH_LOG) || state.isOf(Blocks.SPRUCE_LOG) ||
                state.isOf(Blocks.JUNGLE_LOG) || state.isOf(Blocks.ACACIA_LOG) || state.isOf(Blocks.DARK_OAK_LOG) ||
                state.isOf(Blocks.MANGROVE_LOG) || state.isOf(Blocks.CHERRY_LOG);
    }

    private boolean isLeaves(BlockState state) {
        return state.isOf(Blocks.OAK_LEAVES) || state.isOf(Blocks.BIRCH_LEAVES) || state.isOf(Blocks.SPRUCE_LEAVES) ||
                state.isOf(Blocks.JUNGLE_LEAVES) || state.isOf(Blocks.ACACIA_LEAVES) || state.isOf(Blocks.DARK_OAK_LEAVES) ||
                state.isOf(Blocks.MANGROVE_LEAVES) || state.isOf(Blocks.CHERRY_LEAVES);
    }

    private boolean isTreeBase(BlockPos pos) {
        BlockState below = villager.getWorld().getBlockState(pos.down());
        return below.isOf(Blocks.DIRT) || below.isOf(Blocks.GRASS_BLOCK) || below.isOf(Blocks.PODZOL) ||
                below.isOf(Blocks.COARSE_DIRT) || below.isOf(Blocks.ROOTED_DIRT);
    }

    private boolean isPartOfTree(BlockPos logPos) {
        BlockPos top = logPos;
        while (isLog(villager.getWorld().getBlockState(top.up()))) {
            top = top.up();
        }
        BlockPos.Mutable check = new BlockPos.Mutable();
        for (int dx = -2; dx <= 2; dx++) {
            for (int dy = 0; dy <= 3; dy++) {
                for (int dz = -2; dz <= 2; dz++) {
                    check.set(top.getX() + dx, top.getY() + dy, top.getZ() + dz);
                    if (isLeaves(villager.getWorld().getBlockState(check))) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private boolean isWoodOrSapling(net.minecraft.item.Item item) {
        return item == Items.OAK_LOG || item == Items.BIRCH_LOG || item == Items.SPRUCE_LOG ||
                item == Items.JUNGLE_LOG || item == Items.ACACIA_LOG || item == Items.DARK_OAK_LOG ||
                item == Items.MANGROVE_LOG || item == Items.CHERRY_LOG ||
                item == Items.OAK_SAPLING || item == Items.BIRCH_SAPLING || item == Items.SPRUCE_SAPLING ||
                item == Items.JUNGLE_SAPLING || item == Items.ACACIA_SAPLING || item == Items.DARK_OAK_SAPLING ||
                item == Items.MANGROVE_PROPAGULE || item == Items.CHERRY_SAPLING;
    }
}