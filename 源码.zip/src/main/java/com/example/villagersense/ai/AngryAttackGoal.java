package com.example.villagersense.ai;

import com.example.villagerapi.Rallyable;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.brain.Brain;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.IronGolemEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.entity.projectile.SpectralArrowEntity;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.*;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.village.VillagerProfession;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.*;

public class AngryAttackGoal extends Goal {
    private final VillagerEntity villager;
    private final SimpleInventory inventory;
    private LivingEntity target;
    private int attackCooldown;
    private int broadcastCooldown = 0;

    // 弓相关
    private int rangedAttackCooldown = 0;
    private boolean isBowCharging = false;
    private int bowChargeTime = 0;
    private static final int BOW_CHARGE_DURATION = 20;
    private static final int BOW_ATTACK_INTERVAL = 25; // 0.8次/秒

    // 弩相关
    private int crossbowShotCooldown = 0;                          // 弩射击冷却（0.5秒 = 10 tick）
    private final Map<Integer, ItemStack> loadedCrossbowSlots = new HashMap<>(); // 槽位索引 -> 已装填箭矢

    private enum AttackState { IDLE, FLEEING, CHARGING_BOW, LOADING_CROSSBOW, MELEE }
    private AttackState attackState = AttackState.IDLE;

    public AngryAttackGoal(VillagerEntity villager, SimpleInventory inventory) {
        this.villager = villager;
        this.inventory = inventory;
        this.setControls(EnumSet.of(Control.MOVE, Control.LOOK));
    }

    @Override
    public boolean canStart() {
        var prof = villager.getVillagerData().getProfession();

        // 无业或傻子：保持原有主动索敌逻辑
        if (prof == VillagerProfession.NONE || prof == VillagerProfession.NITWIT) {
            Rallyable rallyable = (Rallyable) villager;
            if (rallyable.getRallyPoint() != null) {
                return true;
            }

            LivingEntity current = villager.getTarget();
            if (current != null && current.isAlive()) {
                if (current instanceof PlayerEntity player && (player.isCreative() || player.isSpectator())) {
                    villager.setTarget(null);
                } else {
                    if (current instanceof CreeperEntity && !canKillCreeper(current)) {
                        villager.setTarget(null);
                        return false;
                    }
                    this.target = current;
                    return true;
                }
            }

            Brain<VillagerEntity> brain = villager.getBrain();
            Optional<UUID> angryMemory = brain.getOptionalMemory(MemoryModuleType.ANGRY_AT);
            if (angryMemory != null && angryMemory.isPresent()) {
                UUID id = angryMemory.get();
                if (villager.getWorld() instanceof ServerWorld sw) {
                    PlayerEntity player = sw.getPlayerByUuid(id);
                    if (player != null && player.isAlive() && !player.isCreative() && !player.isSpectator()
                            && villager.distanceTo(player) < 32) {
                        this.target = player;
                        villager.setTarget(player);
                        return true;
                    } else {
                        brain.forget(MemoryModuleType.ANGRY_AT);
                    }
                }
            }

            if (villager.getWorld() instanceof ServerWorld sw) {
                BlockPos center = villager.getBlockPos();
                Box searchBox = new Box(
                    center.getX() - 32, center.getY() - 2, center.getZ() - 32,
                    center.getX() + 32, center.getY() + 5, center.getZ() + 32
                );
                // 加入视线检测，防止隔墙/地底误索敌
                List<HostileEntity> hostiles = sw.getEntitiesByClass(HostileEntity.class, searchBox,
                        e -> e.isAlive() && canSeeTarget(e));
                if (!hostiles.isEmpty()) {
                    HostileEntity best = null;
                    double bestDist = Double.MAX_VALUE;
                    for (HostileEntity e : hostiles) {
                        if (e instanceof CreeperEntity && !canKillCreeper(e)) continue;
                        double dist = villager.squaredDistanceTo(e);
                        if (dist < bestDist) {
                            bestDist = dist;
                            best = e;
                        }
                    }
                    if (best != null) {
                        this.target = best;
                        villager.setTarget(best);
                        return true;
                    }
                }
            }
            return false;
        }

        // 普通职业村民：直接检查当前目标（被攻击后由 LivingEntityMixin 设置）
        LivingEntity currentTarget = villager.getTarget();
        if (currentTarget != null && currentTarget.isAlive()) {
            if (currentTarget instanceof PlayerEntity player && (player.isCreative() || player.isSpectator())) {
                villager.setTarget(null);
                return false;
            }
            this.target = currentTarget;
            return true;
        }
        return false;
    }

    @Override
    public boolean shouldContinue() {
        if (target instanceof PlayerEntity player && (player.isCreative() || player.isSpectator())) {
            return false;
        }
        if (target instanceof CreeperEntity && !canKillCreeper(target)) {
            return false;
        }
        return target != null && target.isAlive() && villager.distanceTo(target) < 32;
    }

    @Override
    public void start() {
        attackCooldown = 0;
        broadcastCooldown = 0;
        rangedAttackCooldown = 0;
        crossbowShotCooldown = 0;
        isBowCharging = false;
        bowChargeTime = 0;
        loadedCrossbowSlots.clear();
        attackState = AttackState.IDLE;
        if (target != null) {
            if (!villager.getWorld().isClient && target instanceof HostileEntity) {
                villager.playSound(SoundEvents.ENTITY_VILLAGER_NO, 1.0F, 1.0F);
            }
            villager.getNavigation().startMovingTo(target, 1.0D);
            preloadCrossbows();
        }
    }

    @Override
    public void stop() {
        target = null;
        villager.setTarget(null);
        isBowCharging = false;
        bowChargeTime = 0;
        loadedCrossbowSlots.clear();
        attackState = AttackState.IDLE;
    }

    @Override
    public void tick() {
        Rallyable rallyable = (Rallyable) villager;
        rallyable.tickRallyPoint();

        if (target != null && target.isAlive()) {
            if (target instanceof CreeperEntity && !canKillCreeper(target)) {
                villager.setTarget(null);
                target = null;
                return;
            }

            if (broadcastCooldown <= 0) {
                broadcastRallyPoint();
                broadcastCooldown = 40;
            }
            broadcastCooldown--;

            villager.getLookControl().lookAt(target, 30.0F, 30.0F);
            double distSq = villager.squaredDistanceTo(target);
            boolean inMeleeRange = distSq <= 2.2 * 2.2;

            boolean canUseRanged = canUseRangedWeapon();
            boolean hasBowAndArrow = hasBow() && hasArrowItem();
            boolean hasLoadedCrossbow = !loadedCrossbowSlots.isEmpty();

            boolean inRangedRange = isWithinRangedRange(target);
            boolean canSee = canSeeTarget(target);
            boolean noFriendlyBlock = !isFriendlyBlocking(target);

            boolean weaponReady = hasLoadedCrossbow || hasBowAndArrow;
            boolean canShootNow = weaponReady && canUseRanged && inRangedRange && canSee && noFriendlyBlock;

            boolean shouldFlee = canUseRanged && inRangedRange && distSq <= 5.0 * 5.0;

            if (shouldFlee) {
                if (isBowCharging) { isBowCharging = false; bowChargeTime = 0; }
                attackState = AttackState.FLEEING;
                fleeFromTarget();
                if (inMeleeRange && canMeleeAttack()) {
                    if (attackCooldown <= 0) {
                        performMeleeAttack();
                        attackCooldown = (int) Math.max(1, 20.0 / 4.0);
                    }
                }
                if (attackCooldown > 0) attackCooldown--;
                return;
            }

            if (canShootNow) {
                if (hasLoadedCrossbow) {
                    if (isBowCharging) { isBowCharging = false; bowChargeTime = 0; }
                    villager.getNavigation().stop();
                    if (crossbowShotCooldown <= 0) {
                        shootLoadedCrossbow();
                        crossbowShotCooldown = 10;
                    }
                } else if (hasBowAndArrow) {
                    if (isBowCharging) {
                        villager.getNavigation().stop();
                        bowChargeTime--;
                        if (bowChargeTime <= 0) {
                            performBowAttack();
                            isBowCharging = false;
                            rangedAttackCooldown = BOW_ATTACK_INTERVAL;
                        }
                    } else if (rangedAttackCooldown <= 0) {
                        isBowCharging = true;
                        bowChargeTime = BOW_CHARGE_DURATION;
                        villager.getNavigation().stop();
                    }
                }
            } else if (canUseRanged) {
                if (isBowCharging) {
                    villager.getNavigation().stop();
                    bowChargeTime--;
                    if (bowChargeTime <= 0) {
                        performBowAttack();
                        isBowCharging = false;
                        rangedAttackCooldown = BOW_ATTACK_INTERVAL;
                    }
                } else {
                    if (hasLoadedCrossbow && !inRangedRange) {
                        if (!inMeleeRange) {
                            villager.getNavigation().startMovingTo(target, 1.0D);
                        }
                    } else {
                        int unloadedCrossbowSlot = findUnloadedCrossbowSlot();
                        if (unloadedCrossbowSlot >= 0 && hasArrowItem() && !villager.isBaby() && canMeleeAttack()) {
                            double horizDistSq = horizontalDistanceSq(target);
                            if (horizDistSq < 12.0 * 12.0) {
                                fleeFromTarget();
                            } else {
                                startCrossbowLoading(unloadedCrossbowSlot);
                            }
                        } else if (hasBowAndArrow && !inRangedRange) {
                            if (!inMeleeRange) {
                                villager.getNavigation().startMovingTo(target, 1.0D);
                            }
                        } else {
                            villager.getNavigation().stop();
                        }
                    }
                }
            } else {
                if (!canMeleeAttack()) {
                    fleeFromTarget();
                } else {
                    if (inMeleeRange) {
                        villager.getNavigation().stop();
                        if (attackCooldown <= 0) {
                            performMeleeAttack();
                            attackCooldown = (int) Math.max(1, 20.0 / 4.0);
                        }
                    } else {
                        villager.getNavigation().startMovingTo(target, 1.0D);
                    }
                }
            }

            if (attackCooldown > 0) attackCooldown--;
            if (rangedAttackCooldown > 0) rangedAttackCooldown--;
            if (crossbowShotCooldown > 0) crossbowShotCooldown--;
        } else if (target == null && rallyable.getRallyPoint() != null) {
            BlockPos rally = rallyable.getRallyPoint();
            villager.getNavigation().startMovingTo(rally.getX(), rally.getY(), rally.getZ(), 1.0D);

            if (villager.getWorld() instanceof ServerWorld sw) {
                // 加入视线检测
                List<HostileEntity> hostiles = sw.getEntitiesByClass(HostileEntity.class,
                        villager.getBoundingBox().expand(8.0D), e -> e.isAlive() && canSeeTarget(e));
                if (!hostiles.isEmpty()) {
                    HostileEntity best = null;
                    double bestDist = Double.MAX_VALUE;
                    for (HostileEntity e : hostiles) {
                        if (e instanceof CreeperEntity && !canKillCreeper(e)) continue;
                        double d = villager.squaredDistanceTo(e);
                        if (d < bestDist) {
                            bestDist = d;
                            best = e;
                        }
                    }
                    if (best != null) {
                        target = best;
                        villager.setTarget(best);
                        rallyable.clearRallyPoint();
                        attackCooldown = 0;
                        attackState = AttackState.IDLE;
                        return;
                    }
                }
                Brain<VillagerEntity> brain = villager.getBrain();
                Optional<UUID> angry = brain.getOptionalMemory(MemoryModuleType.ANGRY_AT);
                if (angry != null && angry.isPresent()) {
                    UUID id = angry.get();
                    PlayerEntity player = sw.getPlayerByUuid(id);
                    if (player != null && player.isAlive() && !player.isCreative() && !player.isSpectator()
                            && villager.distanceTo(player) < 16) {
                        target = player;
                        villager.setTarget(player);
                        rallyable.clearRallyPoint();
                        attackCooldown = 0;
                        attackState = AttackState.IDLE;
                        return;
                    }
                }
            }

            if (villager.getBlockPos().isWithinDistance(rally, 2.0D)) {
                rallyable.clearRallyPoint();
            }
        }
    }

    // ================= 能力检查 =================

    private boolean hasAxe() {
        for (int i = 0; i < inventory.size(); i++) {
            ItemStack stack = inventory.getStack(i);
            if (!stack.isEmpty() && stack.getItem() instanceof AxeItem) return true;
        }
        return false;
    }

    private boolean isPlayerBlocking(PlayerEntity player) {
        return player.isUsingItem() && player.getActiveItem().getItem() instanceof ShieldItem;
    }

    private boolean canMeleeAttack() {
        if (villager.isBaby()) return false;
        var prof = villager.getVillagerData().getProfession();
        return !prof.equals(VillagerProfession.NITWIT);
    }

    private boolean canUseRangedWeapon() {
        var prof = villager.getVillagerData().getProfession();
        if (prof.equals(VillagerProfession.NITWIT) || villager.isBaby()) return false;
        return (hasBow() && hasArrowItem()) || hasCrossbow() || !loadedCrossbowSlots.isEmpty();
    }

    private boolean hasBow() {
        for (int i = 0; i < inventory.size(); i++) {
            ItemStack stack = inventory.getStack(i);
            if (!stack.isEmpty() && stack.getItem() instanceof BowItem) return true;
        }
        return false;
    }

    private boolean hasCrossbow() {
        return findUnloadedCrossbowSlot() >= 0 || !loadedCrossbowSlots.isEmpty();
    }

    private int findUnloadedCrossbowSlot() {
        for (int i = 0; i < inventory.size(); i++) {
            ItemStack stack = inventory.getStack(i);
            if (!stack.isEmpty() && stack.getItem() instanceof CrossbowItem && !loadedCrossbowSlots.containsKey(i)) {
                return i;
            }
        }
        return -1;
    }

    private boolean hasArrowItem() {
        for (int i = 0; i < inventory.size(); i++) {
            ItemStack stack = inventory.getStack(i);
            if (!stack.isEmpty() && stack.isIn(ItemTags.ARROWS)) {
                return true;
            }
        }
        return false;
    }

    private ItemStack findArrowItem() {
        for (int i = 0; i < inventory.size(); i++) {
            ItemStack stack = inventory.getStack(i);
            if (!stack.isEmpty() && stack.isIn(ItemTags.ARROWS)) {
                return stack.copy();
            }
        }
        return ItemStack.EMPTY;
    }

    private void consumeArrowItem(ItemStack arrow) {
        for (int i = 0; i < inventory.size(); i++) {
            ItemStack stack = inventory.getStack(i);
            if (ItemStack.areItemsEqual(stack, arrow)) {
                stack.decrement(1);
                if (stack.isEmpty()) inventory.setStack(i, ItemStack.EMPTY);
                return;
            }
        }
    }

    // ================= 弓攻击 =================

    private void performBowAttack() {
        World world = villager.getWorld();
        if (!(world instanceof ServerWorld serverWorld)) return;

        ItemStack arrow = findArrowItem();
        if (arrow.isEmpty()) return;

        consumeArrowItem(arrow);
        shootArrow(serverWorld, 3.0f, arrow);
        villager.playSound(SoundEvents.ENTITY_ARROW_SHOOT, 1.0F, 1.0F);
    }

    // ================= 弩攻击 =================

    private void preloadCrossbows() {
        if (villager.isBaby() || villager.getVillagerData().getProfession().equals(VillagerProfession.NITWIT)) return;

        for (int i = 0; i < inventory.size(); i++) {
            ItemStack stack = inventory.getStack(i);
            if (stack.getItem() instanceof CrossbowItem && !loadedCrossbowSlots.containsKey(i)) {
                ItemStack arrow = findArrowItem();
                if (!arrow.isEmpty()) {
                    consumeArrowItem(arrow);
                    loadedCrossbowSlots.put(i, arrow.copy());
                }
            }
        }
    }

    private void startCrossbowLoading(int slot) {
        ItemStack crossbow = inventory.getStack(slot);
        if (crossbow.isEmpty() || !(crossbow.getItem() instanceof CrossbowItem)) return;
        ItemStack arrow = findArrowItem();
        if (arrow.isEmpty()) return;
        consumeArrowItem(arrow);
        loadedCrossbowSlots.put(slot, arrow.copy());
        villager.playSound(SoundEvents.ITEM_CROSSBOW_LOADING_END.value(), 1.0F, 1.0F);
    }

    private void shootLoadedCrossbow() {
        World world = villager.getWorld();
        if (!(world instanceof ServerWorld serverWorld)) return;

        for (Map.Entry<Integer, ItemStack> entry : loadedCrossbowSlots.entrySet()) {
            int slot = entry.getKey();
            ItemStack arrowStack = entry.getValue();
            loadedCrossbowSlots.remove(slot);
            shootArrow(serverWorld, 3.15f, arrowStack);
            villager.playSound(SoundEvents.ENTITY_ARROW_SHOOT, 1.0F, 1.0F);
            return;
        }
    }

    // ================= 箭矢发射 =================

    private void shootArrow(ServerWorld world, float speed, ItemStack arrowStack) {
        if (target == null) return;
        Vec3d eyePos = villager.getEyePos();
        Vec3d targetPos = target.getEyePos();
        Vec3d direction = targetPos.subtract(eyePos).normalize();

        double damage = 5.0;
        if (target instanceof VillagerEntity) {
            damage /= 2.0;
        }

        if (arrowStack.isOf(Items.SPECTRAL_ARROW)) {
            SpectralArrowEntity spectralArrow = EntityType.SPECTRAL_ARROW.create(world);
            if (spectralArrow != null) {
                spectralArrow.setOwner(villager);
                spectralArrow.setDamage(damage);
                spectralArrow.setPosition(eyePos.x, eyePos.y, eyePos.z);
                spectralArrow.setVelocity(direction.x * speed, direction.y * speed, direction.z * speed);
                spectralArrow.setPitch(villager.getPitch());
                spectralArrow.setYaw(villager.getYaw());
                world.spawnEntity(spectralArrow);
            }
        } else {
            ArrowEntity arrow = new ArrowEntity(world, eyePos.x, eyePos.y, eyePos.z,
                    arrowStack, new ItemStack(Items.ARROW));
            arrow.setOwner(villager);
            arrow.setDamage(damage);
            arrow.setVelocity(direction.x * speed, direction.y * speed, direction.z * speed);
            arrow.setPitch(villager.getPitch());
            arrow.setYaw(villager.getYaw());
            world.spawnEntity(arrow);
        }
    }

    // ================= 距离、视线、友军阻挡 =================

    private boolean isWithinRangedRange(LivingEntity target) {
        double dx = target.getX() - villager.getX();
        double dz = target.getZ() - villager.getZ();
        double horizontalDistSq = dx * dx + dz * dz;
        double maxDistSq = 16.0 * 16.0;
        if (target.getY() < villager.getY()) {
            maxDistSq = 64.0 * 64.0;
        }
        return horizontalDistSq <= maxDistSq;
    }

    private double horizontalDistanceSq(LivingEntity target) {
        double dx = target.getX() - villager.getX();
        double dz = target.getZ() - villager.getZ();
        return dx * dx + dz * dz;
    }

    private boolean canSeeTarget(LivingEntity target) {
        Vec3d start = villager.getEyePos();
        Vec3d end = target.getEyePos();
        BlockHitResult hit = villager.getWorld().raycast(new RaycastContext(
                start, end, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, villager));
        return hit.getType() == HitResult.Type.MISS || hit.getBlockPos().equals(target.getBlockPos());
    }

    private boolean isFriendlyBlocking(LivingEntity target) {
        Vec3d start = villager.getEyePos();
        Vec3d end = target.getEyePos();
        double distance = start.distanceTo(end);
        Vec3d direction = end.subtract(start).normalize();
        Box searchBox = new Box(start, end).expand(1.0);
        World world = villager.getWorld();

        List<VillagerEntity> villagers = world.getEntitiesByClass(VillagerEntity.class, searchBox,
                v -> v != villager && v != target && v.isAlive());
        for (VillagerEntity v : villagers) {
            if (isEntityOnLine(v, start, direction, distance)) return true;
        }
        List<IronGolemEntity> golems = world.getEntitiesByClass(IronGolemEntity.class, searchBox,
                g -> g.isAlive());
        for (IronGolemEntity g : golems) {
            if (isEntityOnLine(g, start, direction, distance)) return true;
        }
        return false;
    }

    private boolean isEntityOnLine(LivingEntity entity, Vec3d start, Vec3d direction, double distance) {
        double step = 0.5;
        for (double d = 0; d <= distance; d += step) {
            Vec3d point = start.add(direction.multiply(d));
            if (entity.getBoundingBox().expand(0.2).contains(point)) return true;
        }
        return false;
    }

    // ================= 移动与近战 =================

    private void fleeFromTarget() {
        if (target == null) return;
        Vec3d away = villager.getPos().subtract(target.getPos()).normalize();
        BlockPos fleeTarget = villager.getBlockPos().add((int)(away.x * 5), 0, (int)(away.z * 5));
        World world = villager.getWorld();
        BlockPos ground = findGroundAt(fleeTarget.getX(), fleeTarget.getZ());
        if (ground != null) fleeTarget = ground;
        villager.getNavigation().startMovingTo(fleeTarget.getX(), fleeTarget.getY(), fleeTarget.getZ(), 1.2D);
    }

    private BlockPos findGroundAt(int x, int z) {
        World world = villager.getWorld();
        int startY = villager.getBlockY();
        for (int y = startY; y > world.getBottomY(); y--) {
            BlockPos pos = new BlockPos(x, y, z);
            if (world.getBlockState(pos).isSolid()) return pos.up();
        }
        return null;
    }

    private void performMeleeAttack() {
        if (target == null) return;
        villager.swingHand(Hand.MAIN_HAND);

        if (target instanceof PlayerEntity player && hasAxe() && isPlayerBlocking(player)) {
            player.disableShield();
            int cooldown = 16 + villager.getRandom().nextInt(25);
            attackCooldown = Math.max(attackCooldown, cooldown);
            rangedAttackCooldown = Math.max(rangedAttackCooldown, cooldown);
            crossbowShotCooldown = Math.max(crossbowShotCooldown, cooldown);
            villager.playSound(SoundEvents.ITEM_SHIELD_BREAK, 1.0F, 1.0F);
        }

        float damage = 1.0F;
        ItemStack helmet = villager.getEquippedStack(EquipmentSlot.HEAD);
        if (!helmet.isEmpty() && helmet.getItem() instanceof ArmorItem armor) {
            damage = armor.getProtection();
        }
        int unbreakingLevel = 0;
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            ItemStack stack = villager.getEquippedStack(slot);
            if (!stack.isEmpty()) {
                var enchantment = villager.getWorld().getRegistryManager()
                        .get(RegistryKeys.ENCHANTMENT)
                        .getEntry(Enchantments.UNBREAKING);
                if (enchantment.isPresent()) {
                    unbreakingLevel += EnchantmentHelper.getLevel(enchantment.get(), stack);
                }
            }
        }
        damage += unbreakingLevel;
        if (target instanceof VillagerEntity) {
            damage /= 2.0F;
        }
        target.damage(villager.getDamageSources().mobAttack(villager), damage);
        villager.playSound(SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, 1.0F, 1.0F);
    }

    private boolean canKillCreeper(LivingEntity creeper) {
        float damage = 1.0F;
        ItemStack helmet = villager.getEquippedStack(EquipmentSlot.HEAD);
        if (!helmet.isEmpty() && helmet.getItem() instanceof ArmorItem armor) {
            damage = armor.getProtection();
        }
        int unbreakingLevel = 0;
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            ItemStack stack = villager.getEquippedStack(slot);
            if (!stack.isEmpty()) {
                var enchantment = villager.getWorld().getRegistryManager()
                        .get(RegistryKeys.ENCHANTMENT)
                        .getEntry(Enchantments.UNBREAKING);
                if (enchantment.isPresent()) {
                    unbreakingLevel += EnchantmentHelper.getLevel(enchantment.get(), stack);
                }
            }
        }
        damage += unbreakingLevel;
        return damage * 3 > creeper.getHealth();
    }

    private void broadcastRallyPoint() {
        if (!(villager.getWorld() instanceof ServerWorld sw)) return;
        BlockPos pos = target.getBlockPos();
        List<VillagerEntity> nearby = sw.getEntitiesByClass(VillagerEntity.class,
                villager.getBoundingBox().expand(16.0D), v -> v != villager
                        && (v.getVillagerData().getProfession().equals(VillagerProfession.NONE)
                        || v.getVillagerData().getProfession().equals(VillagerProfession.NITWIT)));
        for (VillagerEntity v : nearby) {
            Rallyable vm = (Rallyable) v;
            if (vm.getRallyPoint() == null && v.getTarget() == null) {
                vm.setRallyPoint(pos);
            }
        }
    }
}