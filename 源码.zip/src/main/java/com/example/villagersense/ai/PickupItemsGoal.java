package com.example.villagersense.ai;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;

import java.util.List;

public class PickupItemsGoal extends Goal {
    private final VillagerEntity villager;
    private final SimpleInventory inventory;

    public PickupItemsGoal(VillagerEntity villager, SimpleInventory inventory) {
        this.villager = villager;
        this.inventory = inventory;
    }

    @Override
    public boolean canStart() {
        List<ItemEntity> items = villager.getWorld().getEntitiesByClass(ItemEntity.class,
                villager.getBoundingBox().expand(2.0D), item -> item.isAlive());
        return !items.isEmpty();
    }

    @Override
    public void tick() {
        List<ItemEntity> items = villager.getWorld().getEntitiesByClass(ItemEntity.class,
                villager.getBoundingBox().expand(2.0D), item -> item.isAlive());
        for (ItemEntity itemEntity : items) {
            ItemStack stack = itemEntity.getStack().copy();

            // 食物优先放入原版物品栏，满足村民繁殖条件
            if (stack.contains(DataComponentTypes.FOOD)) {
                SimpleInventory vanillaInventory = villager.getInventory();
                if (tryAddToInventory(vanillaInventory, stack)) {
                    playPickupSound();
                    itemEntity.discard();
                    continue;
                }
            }

            // 其余物品进入自定义背包
            for (int i = 0; i < inventory.size(); i++) {
                ItemStack invStack = inventory.getStack(i);
                if (invStack.isEmpty()) {
                    inventory.setStack(i, stack);
                    playPickupSound();
                    itemEntity.discard();
                    break;
                } else if (ItemStack.areItemsEqual(invStack, stack) && invStack.getCount() < invStack.getMaxCount()) {
                    int transfer = Math.min(stack.getCount(), invStack.getMaxCount() - invStack.getCount());
                    if (transfer > 0) {
                        stack.decrement(transfer);
                        invStack.increment(transfer);
                        playPickupSound();
                        if (stack.isEmpty()) {
                            itemEntity.discard();
                            break;
                        }
                    }
                }
            }
        }
        autoEquipArmor();
    }

    private void autoEquipArmor() {
        EquipmentSlot[] armorSlots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        for (EquipmentSlot slot : armorSlots) {
            ItemStack currentArmor = villager.getEquippedStack(slot);
            int currentScore = getArmorScore(currentArmor, slot);

            int bestScore = -1;
            int bestSlot = -1;
            for (int i = 0; i < inventory.size(); i++) {
                ItemStack stack = inventory.getStack(i);
                if (stack.isEmpty() || !(stack.getItem() instanceof ArmorItem)) continue;
                ArmorItem armor = (ArmorItem) stack.getItem();
                if (armor.getSlotType() != slot) continue;
                int score = getArmorScore(stack, slot);
                if (score > bestScore) {
                    bestScore = score;
                    bestSlot = i;
                }
            }

            if (bestSlot >= 0 && bestScore > currentScore) {
                ItemStack newArmor = inventory.getStack(bestSlot).copy();
                inventory.setStack(bestSlot, ItemStack.EMPTY);
                if (!currentArmor.isEmpty()) {
                    addToInventory(currentArmor.copy());
                }
                villager.equipStack(slot, newArmor);
            }
        }
    }

    private int getArmorScore(ItemStack stack, EquipmentSlot expectedSlot) {
        if (stack.isEmpty() || !(stack.getItem() instanceof ArmorItem armor)) return -1;
        if (armor.getSlotType() != expectedSlot) return -1;
        return armor.getProtection() * 10 + (int) (armor.getToughness() * 10);
    }

    private void addToInventory(ItemStack stack) {
        for (int i = 0; i < inventory.size(); i++) {
            ItemStack slot = inventory.getStack(i);
            if (slot.isEmpty()) {
                inventory.setStack(i, stack);
                return;
            } else if (ItemStack.areItemsEqual(slot, stack) && slot.getCount() < slot.getMaxCount()) {
                int transfer = Math.min(stack.getCount(), slot.getMaxCount() - slot.getCount());
                stack.decrement(transfer);
                slot.increment(transfer);
                if (stack.isEmpty()) return;
            }
        }
    }

    private boolean tryAddToInventory(SimpleInventory inv, ItemStack stack) {
        for (int i = 0; i < inv.size(); i++) {
            ItemStack slot = inv.getStack(i);
            if (slot.isEmpty()) {
                inv.setStack(i, stack);
                return true;
            } else if (ItemStack.areItemsEqual(slot, stack) && slot.getCount() < slot.getMaxCount()) {
                int transfer = Math.min(stack.getCount(), slot.getMaxCount() - slot.getCount());
                if (transfer > 0) {
                    slot.increment(transfer);
                    stack.decrement(transfer);
                    if (stack.isEmpty()) return true;
                }
            }
        }
        return stack.isEmpty();
    }

    private void playPickupSound() {
        villager.getWorld().playSound(null, villager.getBlockPos(),
                SoundEvents.ENTITY_ITEM_PICKUP, SoundCategory.NEUTRAL, 0.2F,
                (villager.getRandom().nextFloat() - villager.getRandom().nextFloat()) * 0.7F + 1.0F);
    }
}