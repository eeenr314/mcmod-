package com.example.villagersense.gui;

import com.example.villagersense.VillagerSenseConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.CheckboxWidget;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.text.Text;

@Environment(EnvType.CLIENT)
public class ConfigScreen extends Screen {
    private final Screen parent;
    private CheckboxWidget enableConstructionCheckbox;
    private CheckboxWidget enableLumberjackCheckbox;
    private CheckboxWidget enableFirefighterCheckbox;
    private CheckboxWidget enableRevengeCheckbox;
    private CheckboxWidget enableStorageCheckbox;
    private CheckboxWidget enableSynthesizerCheckbox;

    public ConfigScreen(Screen parent) {
        super(Text.literal("村民感官 设置"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int y = 40;
        int lineSpacing = 25;

        this.enableConstructionCheckbox = this.addDrawableChild(
            CheckboxWidget.builder(Text.literal("启用建筑村民"), this.textRenderer)
                .pos(this.width / 2 - 100, y)
                .checked(VillagerSenseConfig.INSTANCE.enableConstruction)
                .build()
        );
        y += lineSpacing;

        this.enableLumberjackCheckbox = this.addDrawableChild(
            CheckboxWidget.builder(Text.literal("启用伐木工村民"), this.textRenderer)
                .pos(this.width / 2 - 100, y)
                .checked(VillagerSenseConfig.INSTANCE.enableLumberjack)
                .build()
        );
        y += lineSpacing;

        this.enableFirefighterCheckbox = this.addDrawableChild(
            CheckboxWidget.builder(Text.literal("启用消防员村民"), this.textRenderer)
                .pos(this.width / 2 - 100, y)
                .checked(VillagerSenseConfig.INSTANCE.enableFirefighter)
                .build()
        );
        y += lineSpacing;

        this.enableRevengeCheckbox = this.addDrawableChild(
            CheckboxWidget.builder(Text.literal("启用复仇村民"), this.textRenderer)
                .pos(this.width / 2 - 100, y)
                .checked(VillagerSenseConfig.INSTANCE.enableRevenge)
                .build()
        );
        y += lineSpacing;

        this.enableStorageCheckbox = this.addDrawableChild(
            CheckboxWidget.builder(Text.literal("启用仓储村民"), this.textRenderer)
                .pos(this.width / 2 - 100, y)
                .checked(VillagerSenseConfig.INSTANCE.enableStorage)
                .build()
        );
        y += lineSpacing;

        this.enableSynthesizerCheckbox = this.addDrawableChild(
            CheckboxWidget.builder(Text.literal("启用合成村民"), this.textRenderer)
                .pos(this.width / 2 - 100, y)
                .checked(VillagerSenseConfig.INSTANCE.enableSynthesizer)
                .build()
        );

        this.addDrawableChild(
            ButtonWidget.builder(ScreenTexts.DONE, btn -> this.close())
                .dimensions(this.width / 2 - 100, this.height - 28, 200, 20)
                .build()
        );
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 15, 0xFFFFFF);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        VillagerSenseConfig.INSTANCE.enableConstruction = this.enableConstructionCheckbox.isChecked();
        VillagerSenseConfig.INSTANCE.enableLumberjack = this.enableLumberjackCheckbox.isChecked();
        VillagerSenseConfig.INSTANCE.enableFirefighter = this.enableFirefighterCheckbox.isChecked();
        VillagerSenseConfig.INSTANCE.enableRevenge = this.enableRevengeCheckbox.isChecked();
        VillagerSenseConfig.INSTANCE.enableStorage = this.enableStorageCheckbox.isChecked();
        VillagerSenseConfig.INSTANCE.enableSynthesizer = this.enableSynthesizerCheckbox.isChecked();
        VillagerSenseConfig.INSTANCE.save();
        if (this.client != null) this.client.setScreen(parent);
    }
}