package com.example.villagersense.synthesizer.ai;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.village.VillagerProfession;

import java.lang.reflect.Field;
import java.util.*;

public class EnchantmentApplyGoal extends Goal {
    private final VillagerEntity villager;
    private final SimpleInventory inventory;
    private int cooldown;

    public EnchantmentApplyGoal(VillagerEntity villager, SimpleInventory inventory) {
        this.villager = villager;
        this.inventory = inventory;
        this.setControls(EnumSet.of(Control.LOOK));
        this.cooldown = 0;
    }

    @Override
    public boolean canStart() {
        if (!villager.getVillagerData().getProfession().equals(VillagerProfession.TOOLSMITH)) return false;
        if (cooldown > 0) { cooldown--; return false; }
        cooldown = 60;
        return true;
    }

    @Override
    public void start() {
        transferEnchantedBooksFromNearby();
        List<ArmorTarget> allArmor = collectAllArmor();
        if (allArmor.isEmpty()) return;
        ArmorTarget target = allArmor.get(villager.getRandom().nextInt(allArmor.size()));
        tryApplyBookToArmor(target);
    }

    private void transferEnchantedBooksFromNearby() {
        List<VillagerEntity> nearby = villager.getWorld().getEntitiesByClass(VillagerEntity.class,
                villager.getBoundingBox().expand(5.0), v -> v != villager);
        for (VillagerEntity target : nearby) {
            SimpleInventory targetInv = getInventory(target);
            if (targetInv == null) continue;
            for (int i = 0; i < targetInv.size(); i++) {
                ItemStack stack = targetInv.getStack(i);
                if (stack.getItem() == Items.ENCHANTED_BOOK) {
                    if (tryAddToInventory(inventory, stack.copy())) {
                        targetInv.setStack(i, ItemStack.EMPTY);
                    }
                }
            }
        }
    }

    private void tryApplyBookToArmor(ArmorTarget target) {
        for (int i = 0; i < inventory.size(); i++) {
            ItemStack bookStack = inventory.getStack(i);
            if (bookStack.getItem() != Items.ENCHANTED_BOOK) continue;

            var enchantmentsComponent = EnchantmentHelper.getEnchantments(bookStack);
            if (enchantmentsComponent.isEmpty()) continue;

            for (var entry : enchantmentsComponent.getEnchantmentEntries()) {
                RegistryEntry<Enchantment> ench = entry.getKey();
                int bookLevel = entry.getValue();

                if (!ench.value().isAcceptableItem(target.stack)) continue;

                int existingLevel = EnchantmentHelper.getLevel(ench, target.stack);

                if (existingLevel < bookLevel) {
                    target.stack.addEnchantment(ench, bookLevel);
                    bookStack.decrement(1);
                    if (bookStack.isEmpty()) inventory.setStack(i, ItemStack.EMPTY);
                    return;
                } else if (existingLevel == bookLevel) {
                    target.stack.addEnchantment(ench, existingLevel + 1);
                    bookStack.decrement(1);
                    if (bookStack.isEmpty()) inventory.setStack(i, ItemStack.EMPTY);
                    return;
                }
            }
        }
    }

    private List<ArmorTarget> collectAllArmor() {
        List<ArmorTarget> list = new ArrayList<>();
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            if (isArmorSlot(slot)) {
                ItemStack stack = villager.getEquippedStack(slot);
                if (!stack.isEmpty()) list.add(new ArmorTarget(villager, stack, slot));
            }
        }
        List<VillagerEntity> nearby = villager.getWorld().getEntitiesByClass(VillagerEntity.class,
                villager.getBoundingBox().expand(5.0), v -> v != villager);
        for (VillagerEntity v : nearby) {
            for (EquipmentSlot slot : EquipmentSlot.values()) {
                if (isArmorSlot(slot)) {
                    ItemStack stack = v.getEquippedStack(slot);
                    if (!stack.isEmpty()) list.add(new ArmorTarget(v, stack, slot));
                }
            }
        }
        return list;
    }

    private boolean isArmorSlot(EquipmentSlot slot) {
        return slot == EquipmentSlot.HEAD || slot == EquipmentSlot.CHEST
                || slot == EquipmentSlot.LEGS || slot == EquipmentSlot.FEET;
    }

    private SimpleInventory getInventory(VillagerEntity entity) {
        try {
            Field field = entity.getClass().getDeclaredField("villagerInventory");
            field.setAccessible(true);
            return (SimpleInventory) field.get(entity);
        } catch (NoSuchFieldException | IllegalAccessException e1) {
            try {
                Field field = entity.getClass().getDeclaredField("synthesizerInventory");
                field.setAccessible(true);
                return (SimpleInventory) field.get(entity);
            } catch (NoSuchFieldException | IllegalAccessException e2) {
                return null;
            }
        }
    }

    private boolean tryAddToInventory(SimpleInventory inv, ItemStack stack) {
        for (int i = 0; i < inv.size(); i++) {
            ItemStack slot = inv.getStack(i);
            if (slot.isEmpty()) {
                inv.setStack(i, stack);
                return true;
            } else if (ItemStack.areItemsEqual(slot, stack) && slot.getCount() < slot.getMaxCount()) {
                int transfer = Math.min(stack.getCount(), slot.getMaxCount() - slot.getCount());
                if (transfer > 0) {
                    slot.increment(transfer);
                    stack.decrement(transfer);
                    if (stack.isEmpty()) return true;
                }
            }
        }
        return stack.isEmpty();
    }

    private record ArmorTarget(VillagerEntity owner, ItemStack stack, EquipmentSlot slot) {}
}