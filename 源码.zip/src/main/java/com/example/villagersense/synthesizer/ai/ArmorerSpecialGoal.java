package com.example.villagersense.synthesizer.ai;

import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.*;
import net.minecraft.village.VillagerProfession;

import java.util.*;

public class ArmorerSpecialGoal extends Goal {
    private final VillagerEntity villager;
    private final SimpleInventory inventory;
    private int cooldown;

    private static final Map<Item, ArmorSet> ARMOR_MAP = new LinkedHashMap<>();
    static {
        ARMOR_MAP.put(Items.NETHERITE_INGOT, new ArmorSet(
                Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE, Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS));
        ARMOR_MAP.put(Items.DIAMOND, new ArmorSet(
                Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE, Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS));
        ARMOR_MAP.put(Items.IRON_INGOT, new ArmorSet(
                Items.IRON_HELMET, Items.IRON_CHESTPLATE, Items.IRON_LEGGINGS, Items.IRON_BOOTS));
        ARMOR_MAP.put(Items.IRON_NUGGET, new ArmorSet(
                Items.CHAINMAIL_HELMET, Items.CHAINMAIL_CHESTPLATE, Items.CHAINMAIL_LEGGINGS, Items.CHAINMAIL_BOOTS));
        ARMOR_MAP.put(Items.GOLD_INGOT, new ArmorSet(
                Items.GOLDEN_HELMET, Items.GOLDEN_CHESTPLATE, Items.GOLDEN_LEGGINGS, Items.GOLDEN_BOOTS));
        ARMOR_MAP.put(Items.LEATHER, new ArmorSet(
                Items.LEATHER_HELMET, Items.LEATHER_CHESTPLATE, Items.LEATHER_LEGGINGS, Items.LEATHER_BOOTS));
    }

    private static final int HELMET_COST = 5;
    private static final int CHESTPLATE_COST = 8;
    private static final int LEGGINGS_COST = 7;
    private static final int BOOTS_COST = 4;

    public ArmorerSpecialGoal(VillagerEntity villager, SimpleInventory inventory) {
        this.villager = villager;
        this.inventory = inventory;
        this.setControls(EnumSet.of(Control.LOOK));
        this.cooldown = 0;
    }

    @Override
    public boolean canStart() {
        if (villager.isBaby()) return false;
        if (!villager.getVillagerData().getProfession().equals(VillagerProfession.ARMORER)) return false;
        if (cooldown > 0) { cooldown--; return false; }
        cooldown = 60;
        return true;
    }

    @Override
    public void start() {
        craftForSelf();
        shareArmor();
    }

    private void craftForSelf() {
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        for (EquipmentSlot slot : slots) {
            if (!villager.getEquippedStack(slot).isEmpty()) continue;
            for (Map.Entry<Item, ArmorSet> entry : ARMOR_MAP.entrySet()) {
                Item material = entry.getKey();
                ArmorSet set = entry.getValue();
                Item armorItem = set.get(slot);
                int cost = getCost(slot);
                if (countMaterial(material) >= cost) {
                    removeMaterial(material, cost);
                    villager.equipStack(slot, new ItemStack(armorItem));
                    return;
                }
            }
        }
    }

    private void shareArmor() {
        List<VillagerEntity> nearby = villager.getWorld().getEntitiesByClass(VillagerEntity.class,
                villager.getBoundingBox().expand(5.0), v -> v != villager
                        && !v.getVillagerData().getProfession().equals(VillagerProfession.ARMORER)
                        && !v.isBaby());
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        for (VillagerEntity target : nearby) {
            for (EquipmentSlot slot : slots) {
                if (target.getEquippedStack(slot).isEmpty()) {
                    ItemStack myArmor = villager.getEquippedStack(slot);
                    if (!myArmor.isEmpty()) {
                        target.equipStack(slot, myArmor.copy());
                        villager.equipStack(slot, ItemStack.EMPTY);
                        return;
                    }
                }
            }
        }
    }

    private int countMaterial(Item material) {
        int total = 0;
        for (int i = 0; i < inventory.size(); i++) {
            ItemStack stack = inventory.getStack(i);
            if (stack.isOf(material)) total += stack.getCount();
        }
        return total;
    }

    private void removeMaterial(Item material, int amount) {
        for (int i = 0; i < inventory.size() && amount > 0; i++) {
            ItemStack stack = inventory.getStack(i);
            if (stack.isOf(material)) {
                int toRemove = Math.min(amount, stack.getCount());
                stack.decrement(toRemove);
                if (stack.isEmpty()) inventory.setStack(i, ItemStack.EMPTY);
                amount -= toRemove;
            }
        }
    }

    private int getCost(EquipmentSlot slot) {
        return switch (slot) {
            case HEAD -> HELMET_COST;
            case CHEST -> CHESTPLATE_COST;
            case LEGS -> LEGGINGS_COST;
            case FEET -> BOOTS_COST;
            default -> 0;
        };
    }

    private record ArmorSet(Item helmet, Item chestplate, Item leggings, Item boots) {
        public Item get(EquipmentSlot slot) {
            return switch (slot) {
                case HEAD -> helmet;
                case CHEST -> chestplate;
                case LEGS -> leggings;
                case FEET -> boots;
                default -> Items.AIR;
            };
        }
    }
}