package com.example.villagersense.synthesizer.ai;

import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.village.VillagerProfession;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;

public class ArmorCraftGoal extends Goal {
    private final VillagerEntity villager;
    private final SimpleInventory inventory;
    private int cooldown;

    private static final int HELMET_COST = 5;
    private static final int CHESTPLATE_COST = 8;
    private static final int LEGGINGS_COST = 7;
    private static final int BOOTS_COST = 4;

    public ArmorCraftGoal(VillagerEntity villager, SimpleInventory inventory) {
        this.villager = villager;
        this.inventory = inventory;
        this.setControls(EnumSet.of(Control.LOOK));
        this.cooldown = 0;
    }

    @Override
    public boolean canStart() {
        if (villager.isBaby()) return false;
        var prof = villager.getVillagerData().getProfession();
        if (prof.equals(VillagerProfession.NITWIT) || prof.equals(VillagerProfession.ARMORER)) return false;
        if (cooldown > 0) {
            cooldown--;
            return false;
        }
        cooldown = 60;
        return true;
    }

    @Override
    public void start() {
        List<ArmorRequest> requests = new ArrayList<>();
        if (villager.getEquippedStack(EquipmentSlot.HEAD).isEmpty())
            requests.add(new ArmorRequest(EquipmentSlot.HEAD, Items.IRON_HELMET, HELMET_COST));
        if (villager.getEquippedStack(EquipmentSlot.CHEST).isEmpty())
            requests.add(new ArmorRequest(EquipmentSlot.CHEST, Items.IRON_CHESTPLATE, CHESTPLATE_COST));
        if (villager.getEquippedStack(EquipmentSlot.LEGS).isEmpty())
            requests.add(new ArmorRequest(EquipmentSlot.LEGS, Items.IRON_LEGGINGS, LEGGINGS_COST));
        if (villager.getEquippedStack(EquipmentSlot.FEET).isEmpty())
            requests.add(new ArmorRequest(EquipmentSlot.FEET, Items.IRON_BOOTS, BOOTS_COST));

        if (requests.isEmpty()) return;
        ArmorRequest selected = requests.get(villager.getRandom().nextInt(requests.size()));

        if (countIron() >= selected.cost) {
            removeIron(selected.cost);
            villager.equipStack(selected.slot, new ItemStack(selected.item));
        }
    }

    private int countIron() {
        int total = 0;
        for (int i = 0; i < inventory.size(); i++) {
            ItemStack stack = inventory.getStack(i);
            if (stack.isOf(Items.IRON_INGOT)) total += stack.getCount();
        }
        return total;
    }

    private void removeIron(int amount) {
        for (int i = 0; i < inventory.size() && amount > 0; i++) {
            ItemStack stack = inventory.getStack(i);
            if (stack.isOf(Items.IRON_INGOT)) {
                int toRemove = Math.min(amount, stack.getCount());
                stack.decrement(toRemove);
                if (stack.isEmpty()) inventory.setStack(i, ItemStack.EMPTY);
                amount -= toRemove;
            }
        }
    }

    private record ArmorRequest(EquipmentSlot slot, net.minecraft.item.Item item, int cost) {}
}