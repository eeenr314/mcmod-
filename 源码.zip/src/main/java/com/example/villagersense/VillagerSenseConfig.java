package com.example.villagersense;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class VillagerSenseConfig {
    public static final VillagerSenseConfig INSTANCE = new VillagerSenseConfig();
    private static final File CONFIG_FILE = FabricLoader.getInstance().getConfigDir().resolve("villagersense.json").toFile();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    // 原有字段 ...
    public boolean enableConstruction = true;
    public boolean enableLumberjack = true;
    public boolean enableFirefighter = true;
    public boolean enableRevenge = true;
    public boolean enableStorage = true;
    public boolean enableSynthesizer = true;

    public boolean enablePickup = true;
    public boolean enableNitwitGolem = true;
    public boolean enableAttackPlayer = false;
    public boolean enableAttackHostile = true;
    public boolean enableFirefighting = true;
    public boolean enableWorkProduction = true;
    public boolean enableContainerInteraction = true;
    public boolean enableTreePlanting = true;

    // 新增：傻子村民交易开关
    public boolean enableNitwitTrading = true;

    public static void loadConfig() {
        if (!CONFIG_FILE.exists()) {
            INSTANCE.save();
            return;
        }
        try (FileReader reader = new FileReader(CONFIG_FILE)) {
            VillagerSenseConfig temp = GSON.fromJson(reader, VillagerSenseConfig.class);
            // 全部字段覆盖
            INSTANCE.enableConstruction = temp.enableConstruction;
            INSTANCE.enableLumberjack = temp.enableLumberjack;
            INSTANCE.enableFirefighter = temp.enableFirefighter;
            INSTANCE.enableRevenge = temp.enableRevenge;
            INSTANCE.enableStorage = temp.enableStorage;
            INSTANCE.enableSynthesizer = temp.enableSynthesizer;
            INSTANCE.enablePickup = temp.enablePickup;
            INSTANCE.enableNitwitGolem = temp.enableNitwitGolem;
            INSTANCE.enableAttackPlayer = temp.enableAttackPlayer;
            INSTANCE.enableAttackHostile = temp.enableAttackHostile;
            INSTANCE.enableFirefighting = temp.enableFirefighting;
            INSTANCE.enableWorkProduction = temp.enableWorkProduction;
            INSTANCE.enableContainerInteraction = temp.enableContainerInteraction;
            INSTANCE.enableTreePlanting = temp.enableTreePlanting;
            INSTANCE.enableNitwitTrading = temp.enableNitwitTrading;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void save() {
        try (FileWriter writer = new FileWriter(CONFIG_FILE)) {
            GSON.toJson(this, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}