package com.example.villagersense;

import com.example.villagersense.gui.ConfigScreen;
import com.example.villagersense.keybind.ModKeyBindings;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

public class VillagerSenseModClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ModKeyBindings.register();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (ModKeyBindings.OPEN_MENU.wasPressed()) {
                client.setScreen(new ConfigScreen(client.currentScreen));
            }
        });
    }
}