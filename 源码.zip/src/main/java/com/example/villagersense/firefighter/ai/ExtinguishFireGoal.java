package com.example.villagersense.firefighter.ai;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.village.VillagerProfession;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.EnumSet;
import java.util.List;

public class ExtinguishFireGoal extends Goal {
    private final VillagerEntity villager;
    private BlockPos targetFire;

    public ExtinguishFireGoal(VillagerEntity villager) {
        this.villager = villager;
        this.setControls(EnumSet.of(Control.MOVE, Control.LOOK));
    }

    @Override
    public boolean canStart() {
        if (villager.isBaby()) return false;
        var prof = villager.getVillagerData().getProfession();
        if (prof.equals(VillagerProfession.NITWIT)) return false;
        return isDangerousFireNearby() || isAnyVillagerOnFire();
    }

    @Override
    public boolean shouldContinue() {
        return (targetFire != null && villager.getWorld().getBlockState(targetFire).isOf(Blocks.FIRE))
                || isAnyVillagerOnFire();
    }

    @Override
    public void start() {
        targetFire = null;
    }

    @Override
    public void stop() {
        targetFire = null;
    }

    @Override
    public void tick() {
        World world = villager.getWorld();
        if (world.isClient) return;

        // 扑灭周围着火的村民（不包括自己）
        extinguishNearbyVillagers();

        // 如果自己着火，立即扑灭周围 3x3x3 范围的所有火焰，避免循环
        if (villager.isOnFire()) {
            extinguishAreaAroundSelf();
            return; // 本 tick 结束，不再处理单个目标
        }

        // 常规火焰处理
        if (targetFire == null || !world.getBlockState(targetFire).isOf(Blocks.FIRE)) {
            targetFire = findNearestDangerousFire();
        }

        if (targetFire != null) {
            double distance = villager.getBlockPos().getSquaredDistance(targetFire);
            if (distance <= 8 * 8 && canSeeTarget(targetFire)) {
                world.setBlockState(targetFire, Blocks.AIR.getDefaultState());
                world.playSound(null, targetFire, SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.NEUTRAL, 1.0F, 1.0F);
                spawnWaterParticles(targetFire);
                targetFire = null;
            } else {
                villager.getNavigation().startMovingTo(targetFire.getX(), targetFire.getY(), targetFire.getZ(), 0.7);
            }
        }
    }

    // 扑灭以村民为中心 3x3x3 范围的所有火焰
    private void extinguishAreaAroundSelf() {
        World world = villager.getWorld();
        BlockPos center = villager.getBlockPos();
        BlockPos.Mutable mutable = new BlockPos.Mutable();
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                for (int dz = -1; dz <= 1; dz++) {
                    mutable.set(center.getX() + dx, center.getY() + dy, center.getZ() + dz);
                    if (world.getBlockState(mutable).isOf(Blocks.FIRE)) {
                        world.setBlockState(mutable, Blocks.AIR.getDefaultState(), 3);
                        world.playSound(null, mutable, SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.NEUTRAL, 0.5F, 1.0F);
                        spawnWaterParticles(mutable);
                    }
                }
            }
        }
    }

    private BlockPos findNearestDangerousFire() {
        BlockPos center = villager.getBlockPos();
        BlockPos.Mutable mutable = new BlockPos.Mutable();
        BlockPos closest = null;
        double closestDistSq = Double.MAX_VALUE;
        for (int x = -8; x <= 8; x++) {
            for (int y = -5; y <= 5; y++) {
                for (int z = -8; z <= 8; z++) {
                    mutable.set(center.getX() + x, center.getY() + y, center.getZ() + z);
                    if (villager.getWorld().getBlockState(mutable).isOf(Blocks.FIRE)) {
                        if (hasFlammableNeighbors(mutable)) {
                            double distSq = center.getSquaredDistance(mutable);
                            if (distSq < closestDistSq) {
                                closestDistSq = distSq;
                                closest = mutable.toImmutable();
                            }
                        }
                    }
                }
            }
        }
        return closest;
    }

    private boolean isDangerousFireNearby() {
        return findNearestDangerousFire() != null;
    }

    private boolean hasFlammableNeighbors(BlockPos firePos) {
        World world = villager.getWorld();
        if (isFlammable(world.getBlockState(firePos.down()))) return true;
        if (isFlammable(world.getBlockState(firePos.up()))) return true;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dz == 0) continue;
                BlockPos near = firePos.add(dx, 0, dz);
                if (isFlammable(world.getBlockState(near))) return true;
            }
        }
        return false;
    }

    private boolean isFlammable(BlockState state) {
        if (state.isAir()) return false;
        return state.isIn(BlockTags.LOGS) ||
                state.isIn(BlockTags.LEAVES) ||
                state.isIn(BlockTags.PLANKS) ||
                state.isIn(BlockTags.WOOL) ||
                state.isIn(BlockTags.FLOWERS) ||
                state.isOf(Blocks.COAL_BLOCK) ||
                state.isOf(Blocks.HAY_BLOCK) ||
                state.isOf(Blocks.BOOKSHELF) ||
                state.isOf(Blocks.TNT) ||
                state.isOf(Blocks.VINE) ||
                state.isOf(Blocks.DRIED_KELP_BLOCK);
    }

    private void extinguishNearbyVillagers() {
        World world = villager.getWorld();
        Box box = villager.getBoundingBox().expand(8.0);
        List<VillagerEntity> villagers = world.getEntitiesByClass(VillagerEntity.class, box,
                e -> e != villager && e.isOnFire());
        for (VillagerEntity v : villagers) {
            v.extinguish();
            world.playSound(null, v.getBlockPos(), SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.NEUTRAL, 0.5F, 1.0F);
            spawnWaterParticles(v.getBlockPos());
        }
    }

    private boolean isAnyVillagerOnFire() {
        if (villager.isOnFire()) return true;
        Box box = villager.getBoundingBox().expand(8.0);
        return !villager.getWorld().getEntitiesByClass(VillagerEntity.class, box,
                e -> e != villager && e.isOnFire()).isEmpty();
    }

    private void spawnWaterParticles(BlockPos pos) {
        if (villager.getWorld() instanceof ServerWorld serverWorld) {
            for (int i = 0; i < 10; i++) {
                double x = pos.getX() + 0.5 + (villager.getRandom().nextDouble() - 0.5) * 0.5;
                double y = pos.getY() + 0.5;
                double z = pos.getZ() + 0.5 + (villager.getRandom().nextDouble() - 0.5) * 0.5;
                serverWorld.spawnParticles(ParticleTypes.SPLASH, x, y, z, 1, 0, 0, 0, 0.1);
            }
        }
    }

    private boolean canSeeTarget(BlockPos pos) {
        World world = villager.getWorld();
        Vec3d start = villager.getEyePos();
        Vec3d end = Vec3d.ofCenter(pos);
        BlockHitResult hit = world.raycast(new RaycastContext(start, end,
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, villager));
        return hit.getType() == HitResult.Type.MISS || hit.getBlockPos().equals(pos);
    }
}