package com.example.villagersense.keybind;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

@Environment(EnvType.CLIENT)
public class ModKeyBindings {
    public static final KeyBinding OPEN_MENU = new KeyBinding(
            "key.villager-sense.open_menu",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_O,
            "category.villager-sense.keys"
    );

    public static void register() {
        KeyBindingHelper.registerKeyBinding(OPEN_MENU);
    }
}