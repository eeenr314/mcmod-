package com.example.villagersense;

import com.example.villagersense.integration.ModuleRegistry;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.object.builder.v1.trade.TradeOfferHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.village.TradeOffer;
import net.minecraft.village.TradedItem;
import net.minecraft.village.VillagerProfession;
import java.util.Optional;

public class VillagerSenseMod implements ModInitializer {
    public static final String MOD_ID = "villagersense";

    @Override
    public void onInitialize() {
        VillagerSenseConfig.loadConfig();
        ModuleRegistry.loadFromConfig(VillagerSenseConfig.INSTANCE);

        registerNitwitTrades();
    }

    private void registerNitwitTrades() {
        // 1级：新手
        TradeOfferHelper.registerVillagerOffers(VillagerProfession.NITWIT, 1, factories -> {
            factories.add((entity, random) -> new TradeOffer(
                    new TradedItem(Items.GRASS_BLOCK, 1),
                    new ItemStack(Items.DIRT, 1),
                    Integer.MAX_VALUE, 2, 0.05F
            ));
            factories.add((entity, random) -> new TradeOffer(
                    new TradedItem(Items.DIRT, 2),
                    new ItemStack(Items.GRASS_BLOCK, 1),
                    Integer.MAX_VALUE, 2, 0.05F
            ));
        });

        // 2级：学徒
        TradeOfferHelper.registerVillagerOffers(VillagerProfession.NITWIT, 2, factories -> {
            factories.add((entity, random) -> new TradeOffer(
                    new TradedItem(Items.IRON_INGOT, 1),
                    new ItemStack(Items.GOLD_NUGGET, 1),
                    Integer.MAX_VALUE, 5, 0.05F
            ));
            factories.add((entity, random) -> new TradeOffer(
                    new TradedItem(Items.GRASS_BLOCK, 64),
                    new ItemStack(Items.IRON_NUGGET, 1),
                    Integer.MAX_VALUE, 5, 0.05F
            ));
        });

        // 3级：老手
        TradeOfferHelper.registerVillagerOffers(VillagerProfession.NITWIT, 3, factories -> {
            factories.add((entity, random) -> new TradeOffer(
                    new TradedItem(Items.COBBLESTONE, 4),
                    new ItemStack(Items.DIRT, 1),
                    Integer.MAX_VALUE, 10, 0.05F
            ));
            factories.add((entity, random) -> new TradeOffer(
                    new TradedItem(Items.DIRT, 64),
                    new ItemStack(Items.EMERALD, 1),
                    Integer.MAX_VALUE, 10, 0.05F
            ));
        });

        // 4级：专家
        TradeOfferHelper.registerVillagerOffers(VillagerProfession.NITWIT, 4, factories -> {
            factories.add((entity, random) -> new TradeOffer(
                    new TradedItem(Items.STONE, 1),
                    new ItemStack(Items.COBBLESTONE, 2),
                    Integer.MAX_VALUE, 15, 0.05F
            ));
            factories.add((entity, random) -> new TradeOffer(
                    new TradedItem(Items.EMERALD, 16),
                    new ItemStack(Items.DIAMOND, 1),
                    Integer.MAX_VALUE, 15, 0.05F
            ));
        });

        // 5级：大师
        TradeOfferHelper.registerVillagerOffers(VillagerProfession.NITWIT, 5, factories -> {
            factories.add((entity, random) -> new TradeOffer(
                    new TradedItem(Items.EMERALD, 64),
                    Optional.of(new TradedItem(Items.DIRT, 64)),
                    new ItemStack(Items.NETHERITE_SCRAP, 1),
                    Integer.MAX_VALUE, 30, 0.05F
            ));
            factories.add((entity, random) -> new TradeOffer(
                    new TradedItem(Items.DIAMOND, 16),
                    new ItemStack(Items.ANCIENT_DEBRIS, 1),
                    Integer.MAX_VALUE, 30, 0.05F
            ));
        });
    }
}