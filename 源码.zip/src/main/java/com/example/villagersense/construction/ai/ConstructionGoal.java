package com.example.villagersense.construction.ai;

import java.lang.reflect.Field;
import com.example.villagersense.construction.util.LitematicLoader;
import com.example.villagersense.construction.util.LitematicLoader.LitematicData;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.village.VillagerProfession;
import net.minecraft.world.World;

import java.util.*;

public class ConstructionGoal extends Goal {
    private final VillagerEntity villager;
    private int cooldown = 0;
    private State state = State.IDLE;
    private BlockPos constructionSite;
    private int totalTicks = 0;
    private SimpleInventory sharedInventory;

    private int requiredEmeralds = 0;
    private static final int VOLUME_PER_EMERALD = 16;
    private LitematicData selectedSchematic;
    private boolean usingLitematic = false;
    private int rotation = 0;

    public static final Set<Block> COVERABLE_BLOCKS = buildCoverableBlocks();
    private static final Set<Block> DANGEROUS_GROUND_BLOCKS = buildDangerousGroundBlocks();
    private static final double MAX_DANGEROUS_GROUND_RATIO = 0.10;
    private static final int SEARCH_RADIUS = 16;
    private static final int MAX_RANDOM_ATTEMPTS = 30;

    private enum State {
        IDLE, SELECTING_SITE, BUILDING, COMPLETED
    }
public ConstructionGoal(VillagerEntity villager) {
    this.villager = villager;
    this.setControls(EnumSet.of(Control.MOVE, Control.LOOK));
    this.sharedInventory = getSharedInventory(villager);
}

private SimpleInventory getSharedInventory(VillagerEntity villager) {
    try {
        Field field = villager.getClass().getDeclaredField("villagerInventory");
        field.setAccessible(true);
        return (SimpleInventory) field.get(villager);
    } catch (NoSuchFieldException | IllegalAccessException e) {
        // 如果找不到，回退到一个临时背包（但支付将无法工作）
        return new SimpleInventory(18);
    }
}

    private boolean canPay() { return getTotalEmeraldValue() >= requiredEmeralds; }
    private int getTotalEmeraldValue() {
        int value = 0;
        for (int i = 0; i < sharedInventory.size(); i++) {
            ItemStack stack = sharedInventory.getStack(i);
            if (stack.isOf(Items.EMERALD)) value += stack.getCount();
            else if (stack.isOf(Items.EMERALD_BLOCK)) value += stack.getCount() * 9;
        }
        return value;
    }
    private void deductEmeralds(int amount) {
        for (int i = 0; i < sharedInventory.size() && amount > 0; i++) {
            ItemStack stack = sharedInventory.getStack(i);
            if (stack.isOf(Items.EMERALD_BLOCK)) {
                int blocks = Math.min(amount / 9, stack.getCount());
                if (blocks > 0) { stack.decrement(blocks); amount -= blocks * 9; if (stack.isEmpty()) sharedInventory.setStack(i, ItemStack.EMPTY); }
                else if (amount < 9 && stack.getCount() > 0) {
                    stack.decrement(1); if (stack.isEmpty()) sharedInventory.setStack(i, ItemStack.EMPTY);
                    addEmeralds(9 - amount); amount = 0;
                }
            }
        }
        for (int i = 0; i < sharedInventory.size() && amount > 0; i++) {
            ItemStack stack = sharedInventory.getStack(i);
            if (stack.isOf(Items.EMERALD)) {
                int take = Math.min(amount, stack.getCount());
                stack.decrement(take); amount -= take;
                if (stack.isEmpty()) sharedInventory.setStack(i, ItemStack.EMPTY);
            }
        }
    }
    private void addEmeralds(int count) {
        ItemStack em = new ItemStack(Items.EMERALD, count);
        for (int i = 0; i < sharedInventory.size(); i++) {
            ItemStack slot = sharedInventory.getStack(i);
            if (slot.isEmpty()) { sharedInventory.setStack(i, em); return; }
            else if (slot.isOf(Items.EMERALD) && slot.getCount() < slot.getMaxCount()) {
                int tr = Math.min(count, slot.getMaxCount() - slot.getCount());
                slot.increment(tr); em.decrement(tr);
                if (em.isEmpty()) return;
            }
        }
    }

    @Override
public boolean canStart() {
    // 排除小村民和傻子
    if (villager.isBaby()) {
        System.out.println("[Construction] skip: baby");
        return false;
    }
    var prof = villager.getVillagerData().getProfession();
    if (prof.equals(VillagerProfession.NITWIT)) {
        System.out.println("[Construction] skip: nitwit");
        return false;
    }

    // 冷却
    if (cooldown > 0) {
        System.out.println("[Construction] skip: cooldown " + cooldown);
        cooldown--;
        return false;
    }
    cooldown = 200;

    // 加载投影
    List<LitematicData> schematics = LitematicLoader.loadAllSchematics();
    System.out.println("[Construction] schematics count: " + schematics.size());
    if (schematics.isEmpty()) return false;

    selectedSchematic = schematics.get(villager.getRandom().nextInt(schematics.size()));
    requiredEmeralds = (int) Math.ceil((double) selectedSchematic.volume / VOLUME_PER_EMERALD);
    System.out.println("[Construction] selected schematic, needs emeralds: " + requiredEmeralds);
    rotation = villager.getRandom().nextInt(4) * 90;

    // 检查支付
    boolean pay = canPay();
    System.out.println("[Construction] canPay: " + pay + " (has " + getTotalEmeraldValue() + ")");
    return pay;
}

    @Override
    public void start() {
        if (state != State.IDLE) return;
        state = State.SELECTING_SITE;
        totalTicks = 0;
    }

    @Override
    public boolean shouldContinue() {
        if (totalTicks > 1200) { abortProject(); return false; }
        return state != State.COMPLETED && state != State.IDLE;
    }

    @Override
    public void tick() {
        totalTicks++;
        switch (state) {
            case SELECTING_SITE:
                findAndPrepareSite();
                if (constructionSite != null) state = State.BUILDING;
                else abortProject();
                break;
            case BUILDING:
                buildStructure();
                break;
        }
    }

    @Override
    public void stop() { state = State.IDLE; }

    private void findAndPrepareSite() {
        int w = selectedSchematic.width;
        int d = selectedSchematic.depth;
        int h = selectedSchematic.height;
        if (rotation == 90 || rotation == 270) {
            int tmp = w;
            w = d;
            d = tmp;
        }
        BlockPos villagerPos = villager.getBlockPos();
        var random = villager.getRandom();

        for (int attempt = 0; attempt < MAX_RANDOM_ATTEMPTS; attempt++) {
            int dx = random.nextBetween(-SEARCH_RADIUS, SEARCH_RADIUS);
            int dz = random.nextBetween(-SEARCH_RADIUS, SEARCH_RADIUS);
            int searchX = villagerPos.getX() + dx;
            int searchZ = villagerPos.getZ() + dz;
            int groundY = findGroundAt(searchX, searchZ);
            if (groundY < 0 || Math.abs(groundY - villagerPos.getY()) > 3) continue;
            BlockPos base = new BlockPos(searchX, groundY + 1, searchZ);
            if (isSiteSuitable(base, w, d, h)) {
                constructionSite = base;
                return;
            }
        }
        constructionSite = null;
    }

    private int findGroundAt(int x, int z) {
        World world = villager.getWorld();
        int startY = Math.min(villager.getBlockY() + 2, world.getTopY() - 1);
        int minY = world.getBottomY();
        for (int y = startY; y > minY; y--) {
            BlockPos pos = new BlockPos(x, y, z);
            BlockState state = world.getBlockState(pos);
            if (state.isSolid() && isCoverable(state) && !state.isIn(BlockTags.LEAVES) && !state.isIn(BlockTags.LOGS)) {
                BlockPos above1 = pos.up();
                BlockPos above2 = pos.up(2);
                BlockPos above3 = pos.up(3);
                if (world.getBlockState(above1).isAir() && isCoverable(world.getBlockState(above1)) &&
                        world.getBlockState(above2).isAir() && isCoverable(world.getBlockState(above2)) &&
                        world.getBlockState(above3).isAir() && isCoverable(world.getBlockState(above3))) {
                    return y;
                }
            }
        }
        return -1;
    }

    private boolean isSiteSuitable(BlockPos base, int w, int d, int h) {
        World world = villager.getWorld();
        int checkHeight = h + 1;

        for (int x = 0; x < w; x++) {
            for (int z = 0; z < d; z++) {
                for (int y = 0; y < checkHeight; y++) {
                    BlockState st = world.getBlockState(base.add(x, y, z));
                    if (!st.isAir() && !isCoverable(st)) return false;
                }
            }
        }

        Box area = new Box(base.getX(), base.getY(), base.getZ(),
                base.getX() + w, base.getY() + checkHeight, base.getZ() + d);
        if (!world.getEntitiesByClass(LivingEntity.class, area, e -> true).isEmpty()) return false;

        for (int x = 0; x < w; x++) for (int z = 0; z < d; z++) for (int y = -2; y < 0; y++) {
            BlockState st = world.getBlockState(base.add(x, y, z));
            if (st.isIn(BlockTags.BEDS) || st.isOf(Blocks.CRAFTING_TABLE) || st.isOf(Blocks.FURNACE) ||
                    st.isOf(Blocks.CHEST) || st.isOf(Blocks.TRAPPED_CHEST) || st.isOf(Blocks.FARMLAND) || st.isOf(Blocks.DIRT_PATH)) return false;
        }

        int dangerous = 0;
        int groundTotal = w * d * 2;
        for (int x = 0; x < w; x++) for (int z = 0; z < d; z++) for (int y = -2; y < 0; y++) {
            if (isDangerousGround(world.getBlockState(base.add(x, y, z)))) dangerous++;
        }
        return (double) dangerous / groundTotal <= MAX_DANGEROUS_GROUND_RATIO;
    }

    public static boolean isCoverable(BlockState state) {
        return state.isAir() || COVERABLE_BLOCKS.contains(state.getBlock());
    }
    private boolean isDangerousGround(BlockState s) { return DANGEROUS_GROUND_BLOCKS.contains(s.getBlock()); }

    private void buildStructure() {
System.out.println("[Construction] attempting to build at " + constructionSite);
        if (constructionSite == null) return;
        ServerWorld world = (ServerWorld) villager.getWorld();
        int w = selectedSchematic.width;
        int d = selectedSchematic.depth;
        int h = selectedSchematic.height;
        if (rotation == 90 || rotation == 270) { int tmp = w; w = d; d = tmp; }
        if (!isSiteSuitable(constructionSite, w, d, h)) {
            abortProject();
            return;
        }
        if (LitematicLoader.place(world, constructionSite, selectedSchematic, rotation)) {
            deductEmeralds(requiredEmeralds);
            state = State.COMPLETED;
        } else {
            abortProject();
        }
    }

    private static Set<Block> buildCoverableBlocks() {
        Set<Block> set = new HashSet<>();
        set.add(Blocks.GRASS_BLOCK); set.add(Blocks.DIRT); set.add(Blocks.COARSE_DIRT);
        set.add(Blocks.PODZOL); set.add(Blocks.MYCELIUM); set.add(Blocks.SAND); set.add(Blocks.RED_SAND);
        set.add(Blocks.GRAVEL); set.add(Blocks.CLAY); set.add(Blocks.MUD); set.add(Blocks.MUDDY_MANGROVE_ROOTS);
        set.add(Blocks.STONE); set.add(Blocks.GRANITE); set.add(Blocks.DIORITE); set.add(Blocks.ANDESITE);
        set.add(Blocks.DEEPSLATE); set.add(Blocks.TUFF); set.add(Blocks.CALCITE);
        set.add(Blocks.DRIPSTONE_BLOCK); set.add(Blocks.POINTED_DRIPSTONE);
        set.add(Blocks.SANDSTONE); set.add(Blocks.RED_SANDSTONE);
        set.add(Blocks.COAL_ORE); set.add(Blocks.DEEPSLATE_COAL_ORE); set.add(Blocks.IRON_ORE);
        set.add(Blocks.DEEPSLATE_IRON_ORE); set.add(Blocks.COPPER_ORE); set.add(Blocks.DEEPSLATE_COPPER_ORE);
        set.add(Blocks.GOLD_ORE); set.add(Blocks.DEEPSLATE_GOLD_ORE); set.add(Blocks.REDSTONE_ORE);
        set.add(Blocks.DEEPSLATE_REDSTONE_ORE); set.add(Blocks.LAPIS_ORE); set.add(Blocks.DEEPSLATE_LAPIS_ORE);
        set.add(Blocks.DIAMOND_ORE); set.add(Blocks.DEEPSLATE_DIAMOND_ORE); set.add(Blocks.EMERALD_ORE);
        set.add(Blocks.DEEPSLATE_EMERALD_ORE); set.add(Blocks.NETHER_GOLD_ORE); set.add(Blocks.ANCIENT_DEBRIS);
        set.add(Blocks.SHORT_GRASS); set.add(Blocks.TALL_GRASS); set.add(Blocks.FERN); set.add(Blocks.LARGE_FERN);
        set.add(Blocks.DEAD_BUSH);
        set.add(Blocks.DANDELION); set.add(Blocks.POPPY); set.add(Blocks.BLUE_ORCHID);
        set.add(Blocks.ALLIUM); set.add(Blocks.AZURE_BLUET); set.add(Blocks.RED_TULIP);
        set.add(Blocks.ORANGE_TULIP); set.add(Blocks.WHITE_TULIP); set.add(Blocks.PINK_TULIP);
        set.add(Blocks.OXEYE_DAISY); set.add(Blocks.CORNFLOWER); set.add(Blocks.LILY_OF_THE_VALLEY);
        set.add(Blocks.WITHER_ROSE);
        set.add(Blocks.SUNFLOWER); set.add(Blocks.LILAC); set.add(Blocks.ROSE_BUSH); set.add(Blocks.PEONY);
        set.add(Blocks.MOSS_BLOCK); set.add(Blocks.MOSS_CARPET);
        set.add(Blocks.VINE); set.add(Blocks.SEAGRASS); set.add(Blocks.TALL_SEAGRASS);
        set.add(Blocks.KELP); set.add(Blocks.KELP_PLANT);
        set.add(Blocks.SWEET_BERRY_BUSH); set.add(Blocks.GLOW_LICHEN); set.add(Blocks.HANGING_ROOTS);
        set.add(Blocks.WATER); set.add(Blocks.AIR);
        set.add(Blocks.SNOW); set.add(Blocks.SNOW_BLOCK); set.add(Blocks.ICE);
        set.add(Blocks.PACKED_ICE); set.add(Blocks.BLUE_ICE);
        set.add(Blocks.OBSIDIAN); set.add(Blocks.CRYING_OBSIDIAN);
        set.add(Blocks.MAGMA_BLOCK); set.add(Blocks.NETHERRACK);
        set.add(Blocks.BASALT); set.add(Blocks.BLACKSTONE); set.add(Blocks.END_STONE);
        set.add(Blocks.AMETHYST_BLOCK); set.add(Blocks.BUDDING_AMETHYST);
        set.add(Blocks.FIRE);
        set.add(Blocks.ROOTED_DIRT); set.add(Blocks.DIRT_PATH);
        return set;
    }

    private static Set<Block> buildDangerousGroundBlocks() {
        Set<Block> set = new HashSet<>();
        set.add(Blocks.AIR); set.add(Blocks.WATER); set.add(Blocks.LAVA);
        set.add(Blocks.TRIPWIRE); set.add(Blocks.FIRE);
        set.add(Blocks.FARMLAND); set.add(Blocks.DIRT_PATH);
        set.add(Blocks.DANDELION); set.add(Blocks.POPPY); set.add(Blocks.BLUE_ORCHID);
        set.add(Blocks.ALLIUM); set.add(Blocks.AZURE_BLUET); set.add(Blocks.RED_TULIP);
        set.add(Blocks.ORANGE_TULIP); set.add(Blocks.WHITE_TULIP); set.add(Blocks.PINK_TULIP);
        set.add(Blocks.OXEYE_DAISY); set.add(Blocks.CORNFLOWER); set.add(Blocks.LILY_OF_THE_VALLEY);
        set.add(Blocks.WITHER_ROSE);
        set.add(Blocks.SUNFLOWER); set.add(Blocks.LILAC); set.add(Blocks.ROSE_BUSH); set.add(Blocks.PEONY);
        return set;
    }

    private boolean hasNearbyBed() {
        BlockPos c = villager.getBlockPos();
        for (int dx = -10; dx <= 10; dx++) for (int dy = -5; dy <= 5; dy++) for (int dz = -10; dz <= 10; dz++)
            if (villager.getWorld().getBlockState(c.add(dx, dy, dz)).isIn(BlockTags.BEDS)) return true;
        return false;
    }
    private boolean hasWorkstation() {
        var p = villager.getVillagerData().getProfession();
        return !p.equals(VillagerProfession.NONE) && !p.equals(VillagerProfession.NITWIT);
    }
    private boolean isInventoryOver60Percent() {
        int filled = 0;
        for (int i = 0; i < sharedInventory.size(); i++) if (!sharedInventory.getStack(i).isEmpty()) filled++;
        return (double)filled / sharedInventory.size() > 0.6;
    }
    private void abortProject() { state = State.IDLE; }
}