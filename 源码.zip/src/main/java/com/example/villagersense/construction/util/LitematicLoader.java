package com.example.villagersense.construction.util;

import com.example.villagersense.construction.ai.ConstructionGoal;
import com.google.gson.JsonArray;
import com.google.gson.JsonParser;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.nbt.*;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.math.BlockPos;
import net.fabricmc.loader.api.FabricLoader;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class LitematicLoader {

    public static class LitematicData {
        public final int width, height, depth;
        public final int volume;
        public final List<BlockPlacement> blocks;
        public final String name;

        public LitematicData(String name, int width, int height, int depth, List<BlockPlacement> blocks) {
            this.name = name;
            this.width = width;
            this.height = height;
            this.depth = depth;
            this.volume = width * height * depth;
            this.blocks = blocks;
        }
    }

    public static class BlockPlacement {
        public final BlockState state;
        public final int x, y, z;
        public BlockPlacement(BlockState state, int x, int y, int z) {
            this.state = state;
            this.x = x;
            this.y = y;
            this.z = z;
        }
    }

    public static List<LitematicData> loadAllSchematics() {
        List<LitematicData> result = new ArrayList<>();
        result.addAll(loadBuiltInSchematics());
        result.addAll(loadExternalSchematics());
        return result;
    }

    private static List<LitematicData> loadBuiltInSchematics() {
        List<LitematicData> list = new ArrayList<>();
        try (InputStream listStream = LitematicLoader.class.getResourceAsStream("/jz_list.json")) {
            if (listStream == null) return list;
            String json = new String(listStream.readAllBytes());
            JsonArray arr = JsonParser.parseString(json).getAsJsonArray();
            for (int i = 0; i < arr.size(); i++) {
                String fileName = arr.get(i).getAsString();
                try (InputStream fileStream = LitematicLoader.class.getResourceAsStream("/jz/" + fileName)) {
                    if (fileStream == null) continue;
                    LitematicData data = loadFromStream(fileStream, fileName);
                    if (data != null) list.add(data);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return list;
    }

    private static List<LitematicData> loadExternalSchematics() {
        List<LitematicData> list = new ArrayList<>();
        Path jzDir = FabricLoader.getInstance().getGameDir().resolve("jz");
        if (!Files.exists(jzDir)) return list;
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(jzDir, "*.litematic")) {
            for (Path file : stream) {
                LitematicData data = loadFromFile(file);
                if (data != null) list.add(data);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return list;
    }

    private static LitematicData loadFromFile(Path file) {
        try (InputStream is = Files.newInputStream(file)) {
            return loadFromStream(is, file.getFileName().toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private static LitematicData loadFromStream(InputStream inputStream, String name) {
        try (DataInputStream dataStream = new DataInputStream(new BufferedInputStream(inputStream))) {
            NbtCompound rootNbt = NbtIo.readCompressed(dataStream, NbtSizeTracker.ofUnlimitedBytes());

            NbtCompound metadata = rootNbt.getCompound("Metadata");
            NbtCompound encSize = metadata.getCompound("EnclosingSize");
            int totalWidth = encSize.getInt("x");
            int totalHeight = encSize.getInt("y");
            int totalDepth = encSize.getInt("z");

            NbtCompound regions = rootNbt.getCompound("Regions");
            List<BlockPlacement> allPlacements = new ArrayList<>();

            for (String regionName : regions.getKeys()) {
                NbtCompound region = regions.getCompound(regionName);
                NbtCompound posTag = region.getCompound("Position");
                NbtCompound sizeTag = region.getCompound("Size");
                int regX = posTag.getInt("x");
                int regY = posTag.getInt("y");
                int regZ = posTag.getInt("z");
                int sizeX = Math.abs(sizeTag.getInt("x"));
                int sizeY = Math.abs(sizeTag.getInt("y"));
                int sizeZ = Math.abs(sizeTag.getInt("z"));

                NbtList paletteList = region.getList("BlockStatePalette", NbtElement.COMPOUND_TYPE);
                List<BlockState> palette = new ArrayList<>(paletteList.size());
                for (int i = 0; i < paletteList.size(); i++) {
                    NbtCompound blockNbt = paletteList.getCompound(i);
                    BlockState state = BlockState.CODEC.parse(NbtOps.INSTANCE, blockNbt)
                            .result().orElse(Blocks.AIR.getDefaultState());
                    palette.add(state);
                }

                long[] blockStates = region.getLongArray("BlockStates");
                int bitsPerIndex = Math.max(2, Integer.SIZE - Integer.numberOfLeadingZeros(palette.size() - 1));
                long mask = (1L << bitsPerIndex) - 1;
                int totalBlocks = sizeX * sizeY * sizeZ;

                for (int i = 0; i < totalBlocks; i++) {
                    int startBit = i * bitsPerIndex;
                    int startLong = startBit / 64;
                    int endLong = (startBit + bitsPerIndex - 1) / 64;
                    int paletteIndex;
                    if (startLong == endLong) {
                        int offset = startBit % 64;
                        paletteIndex = (int) ((blockStates[startLong] >>> offset) & mask);
                    } else {
                        int startOffset = startBit % 64;
                        int endOffset = 64 - startOffset;
                        long value = (blockStates[startLong] >>> startOffset) & mask;
                        value |= (blockStates[endLong] & ((1L << (bitsPerIndex - endOffset)) - 1)) << endOffset;
                        paletteIndex = (int) value;
                    }
                    if (paletteIndex < 0 || paletteIndex >= palette.size()) continue;

                    int dx = i % sizeX;
                    int dz = (i / sizeX) % sizeZ;
                    int dy = i / (sizeX * sizeZ);

                    BlockState state = palette.get(paletteIndex);
                    if (!state.isAir()) {
                        allPlacements.add(new BlockPlacement(state, regX + dx, regY + dy, regZ + dz));
                    }
                }
            }

            return new LitematicData(name, totalWidth, totalHeight, totalDepth, allPlacements);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static boolean place(ServerWorld world, BlockPos origin, LitematicData data, int rotation) {
        int w = data.width;
        int d = data.depth;
        int rw = w, rd = d;
        if (rotation == 90 || rotation == 270) {
            rw = d; rd = w;
        }

        List<BlockPos> placedPositions = new ArrayList<>();

        for (BlockPlacement bp : data.blocks) {
            BlockPos pos = origin.add(rotateBlockPos(bp.x, bp.y, bp.z, w, d, rotation));
            BlockState state = bp.state;
            if (state.isAir()) continue;

            state = rotateState(state, rotation);

            BlockState existing = world.getBlockState(pos);
            if (!existing.isAir() && !ConstructionGoal.isCoverable(existing)) {
                for (BlockPos p : placedPositions) {
                    world.setBlockState(p, Blocks.AIR.getDefaultState(), 3);
                }
                return false;
            }

            world.setBlockState(pos, state, 3);
            placedPositions.add(pos);
        }

        for (BlockPos p : placedPositions) {
            world.updateNeighbors(p, world.getBlockState(p).getBlock());
        }
        return true;
    }

    private static BlockPos rotateBlockPos(int x, int y, int z, int w, int d, int rotation) {
        return switch (rotation) {
            case 0 -> new BlockPos(x, y, z);
            case 90 -> new BlockPos(z, y, w - 1 - x);
            case 180 -> new BlockPos(w - 1 - x, y, d - 1 - z);
            case 270 -> new BlockPos(d - 1 - z, y, x);
            default -> new BlockPos(x, y, z);
        };
    }

    private static BlockState rotateState(BlockState state, int rotation) {
    BlockRotation rot = switch (rotation) {
        case 90 -> BlockRotation.COUNTERCLOCKWISE_90;   // 原来是 CLOCKWISE_90
        case 180 -> BlockRotation.CLOCKWISE_180;        // 180度不变
        case 270 -> BlockRotation.CLOCKWISE_90;         // 原来是 COUNTERCLOCKWISE_90
        default -> BlockRotation.NONE;
    };
    return state.rotate(rot);
}
}