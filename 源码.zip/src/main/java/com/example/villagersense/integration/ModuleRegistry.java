package com.example.villagersense.integration;

import com.example.villagersense.VillagerSenseConfig;

public class ModuleRegistry {

    public static boolean PICKUP_ENABLED;
    public static boolean NITWIT_GOLEM_ENABLED;
    public static boolean ATTACK_PLAYER_ENABLED;
    public static boolean ATTACK_HOSTILE_ENABLED;
    public static boolean FIREFIGHTER_ENABLED;
    public static boolean WORK_PRODUCTION_ENABLED;
    public static boolean CONTAINER_INTERACTION_ENABLED;
    public static boolean LUMBERJACK_ENABLED;
    public static boolean TREE_PLANTING_ENABLED;
    public static boolean SYNTHESIZER_ENABLED;
    public static boolean CONSTRUCTION_ENABLED;

    public static boolean GREEN_MASTER_ENABLED = true;

    public static void loadFromConfig(VillagerSenseConfig config) {
        PICKUP_ENABLED = config.enablePickup;
        NITWIT_GOLEM_ENABLED = config.enableNitwitGolem;
        ATTACK_PLAYER_ENABLED = config.enableAttackPlayer;
        ATTACK_HOSTILE_ENABLED = config.enableAttackHostile;
        FIREFIGHTER_ENABLED = config.enableFirefighting;
        WORK_PRODUCTION_ENABLED = config.enableWorkProduction;
        CONTAINER_INTERACTION_ENABLED = config.enableContainerInteraction;
        LUMBERJACK_ENABLED = config.enableLumberjack;
        TREE_PLANTING_ENABLED = config.enableTreePlanting;
        SYNTHESIZER_ENABLED = config.enableSynthesizer;
        CONSTRUCTION_ENABLED = config.enableConstruction;
    }
}