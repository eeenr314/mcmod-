package com.example.villagersense.mixin;

import com.example.villagersense.construction.ai.ConstructionGoal;
import com.example.villagersense.integration.ModuleRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.passive.MerchantEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(VillagerEntity.class)
public abstract class ConstructionVillagerMixin extends MerchantEntity {

    public ConstructionVillagerMixin(EntityType<? extends MerchantEntity> entityType, World world) {
        super(entityType, world);
    }

    @Inject(method = "<init>", at = @At("RETURN"))
    private void onInit(CallbackInfo ci) {
if (!ModuleRegistry.CONSTRUCTION_ENABLED) return;
        VillagerEntity self = (VillagerEntity) (Object) this;
        if (self.getWorld().isClient) return;
        this.goalSelector.add(6, new ConstructionGoal(self));
    }
}