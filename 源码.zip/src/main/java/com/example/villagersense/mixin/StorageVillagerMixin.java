package com.example.villagersense.mixin;

import com.example.villagersense.storage.ai.StorageInteractionGoal;
import com.example.villagersense.integration.ModuleRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.passive.MerchantEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.lang.reflect.Field;

@Mixin(VillagerEntity.class)
public abstract class StorageVillagerMixin extends MerchantEntity {

    public StorageVillagerMixin(EntityType<? extends MerchantEntity> entityType, World world) {
        super(entityType, world);
    }

    @Unique
    private SimpleInventory sharedInventory = null;

    @Inject(method = "<init>", at = @At("RETURN"))
private void onInit(CallbackInfo ci) {
    VillagerEntity self = (VillagerEntity) (Object) this;
    if (self.getWorld().isClient) return;
    if (!ModuleRegistry.CONTAINER_INTERACTION_ENABLED) return;   // 新增
    sharedInventory = findExternalInventory(self);
    this.goalSelector.add(3, new StorageInteractionGoal(self, sharedInventory));
}

    @Unique
    private SimpleInventory findExternalInventory(VillagerEntity villager) {
        try {
            Field field = villager.getClass().getDeclaredField("villagerInventory");
            field.setAccessible(true);
            return (SimpleInventory) field.get(villager);
        } catch (NoSuchFieldException | IllegalAccessException ignored) {}

        for (Field field : villager.getClass().getDeclaredFields()) {
            if (field.getType() == SimpleInventory.class) {
                field.setAccessible(true);
                try {
                    SimpleInventory inv = (SimpleInventory) field.get(villager);
                    if (inv != null) return inv;
                } catch (IllegalAccessException ignored) {}
            }
        }
        return new SimpleInventory(18);
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        VillagerEntity self = (VillagerEntity) (Object) this;
        if (!self.getWorld().isClient && self.isSleeping() && self.age % 20 == 0) {
            self.heal(1.0F);
        }
    }

    @Inject(method = "onDeath", at = @At("HEAD"))
    private void onDeath(DamageSource source, CallbackInfo ci) {
        VillagerEntity self = (VillagerEntity) (Object) this;
        if (self.getWorld().isClient) return;

        for (EquipmentSlot slot : EquipmentSlot.values()) {
            ItemStack equipped = self.getEquippedStack(slot);
            if (!equipped.isEmpty()) {
                self.dropStack(equipped);
                self.equipStack(slot, ItemStack.EMPTY);
            }
        }
    }
}