package com.example.villagersense.mixin;

import net.minecraft.enchantment.Enchantment;
import com.example.villagersense.integration.ModuleRegistry;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.item.*;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.random.Random;
import net.minecraft.village.VillagerProfession;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

@Mixin(VillagerEntity.class)
public abstract class WorkDropMixin {

    @Inject(method = "playWorkSound", at = @At("HEAD"))
    private void onPlayWorkSound(CallbackInfo ci) {
if (!ModuleRegistry.WORK_PRODUCTION_ENABLED) return;
        VillagerEntity self = (VillagerEntity) (Object) this;
        if (self.getWorld().isClient) return;

        var profession = self.getVillagerData().getProfession();
        Random random = self.getRandom();

        if (profession.equals(VillagerProfession.ARMORER) && random.nextFloat() < 0.15f) {
            dropItem(self, createRandomEnchantedArmor(random));
        } else if (profession.equals(VillagerProfession.BUTCHER) && random.nextFloat() < 0.2f) {
            dropItem(self, new ItemStack(Items.OAK_LOG));
        } else if (profession.equals(VillagerProfession.FARMER)) {
            int breadCount = random.nextFloat() < 0.5f ? 1 : 2;
            dropItem(self, new ItemStack(Items.BREAD, breadCount));
        } else if (profession.equals(VillagerProfession.FLETCHER)) {
            if (random.nextBoolean()) {
                if (random.nextFloat() < 0.05f) {
                    dropItem(self, new ItemStack(Items.BOW));
                }
            } else {
                if (random.nextFloat() < 0.3f) {
                    dropItem(self, new ItemStack(Items.ARROW));
                }
            }
        } else if (profession.equals(VillagerProfession.LIBRARIAN) && random.nextFloat() < 0.05f) {
            dropItem(self, createRandomEnchantedBook(random));
        } else if (profession.equals(VillagerProfession.MASON)) {
            if (random.nextBoolean()) {
                if (random.nextFloat() < 0.4f) {
                    dropItem(self, new ItemStack(Items.STONE));
                }
            } else {
                if (random.nextFloat() < 0.5f) {
                    dropItem(self, new ItemStack(Items.COBBLESTONE));
                }
            }
        } else if (profession.equals(VillagerProfession.SHEPHERD) && random.nextFloat() < 0.5f) {
            dropItem(self, new ItemStack(Items.WHITE_WOOL));
        }
    }

    @Unique
    private void dropItem(VillagerEntity villager, ItemStack stack) {
        villager.getWorld().spawnEntity(new ItemEntity(
                villager.getWorld(), villager.getX(), villager.getY() + 0.5, villager.getZ(), stack
        ));
    }

    @Unique
    private ItemStack createRandomEnchantedArmor(Random random) {
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        EquipmentSlot slot = slots[random.nextInt(slots.length)];
        Item[] materials = {
                Items.LEATHER_HELMET, Items.LEATHER_CHESTPLATE, Items.LEATHER_LEGGINGS, Items.LEATHER_BOOTS,
                Items.IRON_HELMET, Items.IRON_CHESTPLATE, Items.IRON_LEGGINGS, Items.IRON_BOOTS,
                Items.GOLDEN_HELMET, Items.GOLDEN_CHESTPLATE, Items.GOLDEN_LEGGINGS, Items.GOLDEN_BOOTS,
                Items.CHAINMAIL_HELMET, Items.CHAINMAIL_CHESTPLATE, Items.CHAINMAIL_LEGGINGS, Items.CHAINMAIL_BOOTS,
                Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE, Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS
        };
        ItemStack stack = new ItemStack(materials[random.nextInt(materials.length)]);

        ServerWorld world = (ServerWorld) ((VillagerEntity)(Object)this).getWorld();
        var enchantmentRegistry = world.getRegistryManager().get(RegistryKeys.ENCHANTMENT);

        List<RegistryEntry<Enchantment>> possibleEnchants = enchantmentRegistry.streamEntries()
                .filter(entry -> entry.value().isAcceptableItem(stack))
                .map(entry -> (RegistryEntry<Enchantment>) entry)
                .toList();

        if (!possibleEnchants.isEmpty()) {
            int enchantCount = random.nextBetween(1, Math.min(2, possibleEnchants.size()));
            for (int i = 0; i < enchantCount; i++) {
                RegistryEntry<Enchantment> ench = possibleEnchants.get(random.nextInt(possibleEnchants.size()));
                int level = random.nextBetween(1, ench.value().getMaxLevel());
                stack.addEnchantment(ench, level);
            }
        }
        return stack;
    }

    @Unique
    private ItemStack createRandomEnchantedBook(Random random) {
        ServerWorld world = (ServerWorld) ((VillagerEntity)(Object)this).getWorld();
        var enchantmentRegistry = world.getRegistryManager().get(RegistryKeys.ENCHANTMENT);

        RegistryEntry<Enchantment>[] allowed = new RegistryEntry[]{
                enchantmentRegistry.getEntry(Enchantments.PROTECTION).orElseThrow(),
                enchantmentRegistry.getEntry(Enchantments.UNBREAKING).orElseThrow(),
                enchantmentRegistry.getEntry(Enchantments.THORNS).orElseThrow(),
                enchantmentRegistry.getEntry(Enchantments.MENDING).orElseThrow()
        };
        RegistryEntry<Enchantment> ench = allowed[random.nextInt(allowed.length)];
        int level = (ench == allowed[3]) ? 1 : random.nextBetween(1, ench.value().getMaxLevel());

        ItemStack book = new ItemStack(Items.ENCHANTED_BOOK);
        book.addEnchantment(ench, level);
        return book;
    }
}