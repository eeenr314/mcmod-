package com.example.villagersense.mixin;

import com.example.villagerapi.Rallyable;
import com.example.villagersense.ai.AngryAttackGoal;
import com.example.villagersense.ai.PickupItemsGoal;
import com.example.villagersense.integration.ModuleRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.brain.Brain;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.passive.MerchantEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.village.VillagerProfession;
import org.spongepowered.asm.mixin.Implements;
import org.spongepowered.asm.mixin.Interface;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Mixin(VillagerEntity.class)
@Implements(@Interface(iface = Rallyable.class, prefix = "rally$"))
public abstract class VillagerEntityMixin extends MerchantEntity implements Rallyable {

    public VillagerEntityMixin(EntityType<? extends MerchantEntity> entityType, net.minecraft.world.World world) {
        super(entityType, world);
    }

    @Unique
    public final SimpleInventory villagerInventory = new SimpleInventory(18);

    @Unique
    private BlockPos rallyPoint = null;
    @Unique
    private int rallyTime = 0;

    @Inject(method = "<init>", at = @At("RETURN"))
    private void onInit(CallbackInfo ci) {
        VillagerEntity self = (VillagerEntity) (Object) this;
        if (self.getWorld().isClient) return;

        // 拾取功能（独立）
        if (ModuleRegistry.PICKUP_ENABLED) {
            this.goalSelector.add(5, new PickupItemsGoal(self, villagerInventory));
        }

        // 反击模块：所有成年非傻子村民都添加持续攻击目标
        if (ModuleRegistry.ATTACK_PLAYER_ENABLED || ModuleRegistry.ATTACK_HOSTILE_ENABLED) {
            if (!self.isBaby() && self.getVillagerData().getProfession() != VillagerProfession.NITWIT) {
                this.goalSelector.add(0, new AngryAttackGoal(self, villagerInventory));
            }
        }
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        VillagerEntity self = (VillagerEntity) (Object) this;
        if (!self.getWorld().isClient && self.isSleeping() && self.age % 20 == 0) {
            self.heal(1.0F);
        }
    }

    // 在 brain tick 之后强制保持攻击移动，防止恐慌覆盖
    @Inject(method = "tick", at = @At("TAIL"))
    private void onTickTail(CallbackInfo ci) {
        VillagerEntity self = (VillagerEntity) (Object) this;
        if (self.getWorld().isClient) return;

        LivingEntity target = self.getTarget();
        if (target != null && target.isAlive()) {
            // 清除恐慌记忆，阻止大脑系统让村民逃跑
            self.getBrain().forget(MemoryModuleType.IS_PANICKING);
            // 如果当前没有朝目标移动，则重新设置导航
            if (!self.getNavigation().isFollowingPath()) {
                self.getNavigation().startMovingTo(target, 1.0D);
            }
        }
    }

    @Inject(method = "onDeath", at = @At("HEAD"))
    private void onDeath(DamageSource source, CallbackInfo ci) {
        VillagerEntity self = (VillagerEntity) (Object) this;
        if (self.getWorld().isClient) return;

        for (int i = 0; i < villagerInventory.size(); i++) {
            ItemStack stack = villagerInventory.getStack(i);
            if (!stack.isEmpty()) {
                self.dropStack(stack);
            }
        }
        villagerInventory.clear();

        for (EquipmentSlot slot : EquipmentSlot.values()) {
            ItemStack equipped = self.getEquippedStack(slot);
            if (!equipped.isEmpty()) {
                self.dropStack(equipped);
                self.equipStack(slot, ItemStack.EMPTY);
            }
        }

        if (source.getAttacker() instanceof PlayerEntity player) {
            UUID playerUUID = player.getUuid();
            List<VillagerEntity> nearby = self.getWorld().getEntitiesByClass(VillagerEntity.class,
                    self.getBoundingBox().expand(32),
                    v -> v.getVillagerData().getProfession().equals(VillagerProfession.NONE)
                            || v.getVillagerData().getProfession().equals(VillagerProfession.NITWIT));
            for (VillagerEntity v : nearby) {
                Brain<VillagerEntity> brain = v.getBrain();
                brain.remember(MemoryModuleType.ANGRY_AT, playerUUID, 600L);
                if (v.getWorld() instanceof ServerWorld serverWorld) {
                    PlayerEntity targetPlayer = serverWorld.getPlayerByUuid(playerUUID);
                    if (targetPlayer != null && !targetPlayer.isCreative()) {
                        v.setTarget(targetPlayer);
                    }
                }
            }
        }
    }

    public BlockPos rally$getRallyPoint() {
        return rallyPoint;
    }
    public void rally$setRallyPoint(BlockPos pos) {
        this.rallyPoint = pos;
        this.rallyTime = 200;
    }
    public void rally$clearRallyPoint() {
        this.rallyPoint = null;
        this.rallyTime = 0;
    }
    public void rally$tickRallyPoint() {
        if (rallyTime > 0) {
            rallyTime--;
            if (rallyTime <= 0) {
                rallyPoint = null;
            }
        }
    }

    @Inject(method = "writeCustomDataToNbt", at = @At("TAIL"))
    private void onWriteNbt(NbtCompound nbt, CallbackInfo ci) {
        VillagerEntity self = (VillagerEntity) (Object) this;
        NbtList list = new NbtList();
        for (int i = 0; i < villagerInventory.size(); i++) {
            ItemStack stack = villagerInventory.getStack(i);
            if (!stack.isEmpty()) {
                NbtCompound tag = new NbtCompound();
                tag.putInt("Slot", i);
                tag.put("item", stack.encode(self.getRegistryManager()));
                list.add(tag);
            }
        }
        nbt.put("VillagerInventory", list);

        Brain<VillagerEntity> brain = self.getBrain();
        Optional<UUID> angry = brain.getOptionalMemory(MemoryModuleType.ANGRY_AT);
        if (angry != null && angry.isPresent()) {
            nbt.putUuid("AngryAtUUID", angry.get());
        }
    }

    @Inject(method = "readCustomDataFromNbt", at = @At("TAIL"))
    private void onReadNbt(NbtCompound nbt, CallbackInfo ci) {
        VillagerEntity self = (VillagerEntity) (Object) this;
        if (nbt.contains("VillagerInventory")) {
            NbtList list = nbt.getList("VillagerInventory", 10);
            for (int i = 0; i < list.size(); i++) {
                NbtCompound tag = list.getCompound(i);
                int slot = tag.getInt("Slot");
                ItemStack stack = ItemStack.fromNbt(self.getRegistryManager(), tag.get("item"))
                        .orElse(ItemStack.EMPTY);
                if (slot >= 0 && slot < villagerInventory.size()) {
                    villagerInventory.setStack(slot, stack);
                }
            }
        }

        if (nbt.containsUuid("AngryAtUUID")) {
            UUID uuid = nbt.getUuid("AngryAtUUID");
            Brain<VillagerEntity> brain = self.getBrain();
            brain.remember(MemoryModuleType.ANGRY_AT, uuid, 600L);
        }
    }
}