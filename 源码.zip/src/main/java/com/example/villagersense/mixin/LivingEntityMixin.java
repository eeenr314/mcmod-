package com.example.villagersense.mixin;

import com.example.villagersense.integration.ModuleRegistry;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.SwordItem;
import net.minecraft.sound.SoundEvents;
import net.minecraft.village.VillagerData;
import net.minecraft.village.VillagerProfession;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.lang.reflect.Field;

@Mixin(LivingEntity.class)
public class LivingEntityMixin {

    // ========== 绿袍尊者死亡掉落（原功能恢复） ==========
    @Inject(method = "onDeath", at = @At("TAIL"))
    private void onDeathDrop(CallbackInfo ci) {
        if (!((Object) this instanceof VillagerEntity villager)) return;

        VillagerData data = villager.getVillagerData();
        boolean isNitwit = data.getProfession().equals(VillagerProfession.NITWIT);
        int level = data.getLevel();

        if (isNitwit) {
            int count = switch (level) {
                case 1 -> 64;
                case 2 -> 160;
                case 3 -> 400;
                case 4 -> 1000;
                case 5 -> 2500;
                default -> 0;
            };
            if (count > 0) {
                while (count > 0) {
                    int drop = Math.min(count, 64);
                    villager.dropStack(new ItemStack(Items.EMERALD_BLOCK, drop));
                    count -= drop;
                }
            }
        } else {
            int count = switch (level) {
                case 1 -> 2;
                case 2 -> 9;
                case 3 -> 20;
                case 4 -> 31;
                case 5 -> 64;
                default -> 0;
            };
            if (count > 0) {
                villager.dropStack(new ItemStack(Items.EMERALD, count));
            }
        }
    }

    // ========== 村民剑格挡 ==========
    @Inject(method = "damage", at = @At("HEAD"), cancellable = true)
    private void onDamage(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        if (!((Object) this instanceof VillagerEntity villager)) return;
        if (villager.getWorld().isClient) return;
        if (!ModuleRegistry.ATTACK_PLAYER_ENABLED && !ModuleRegistry.ATTACK_HOSTILE_ENABLED) return;

        float swordDamage = getBestSwordDamage(villager);
        if (swordDamage <= 0) return;
        double blockChance = Math.min(1.0, swordDamage / 10.0);
        if (villager.getRandom().nextFloat() < blockChance) {
            cir.setReturnValue(false);
            villager.playSound(SoundEvents.ITEM_SHIELD_BLOCK, 1.0F, 1.0F);
        }
    }

    // 通过反射获取村民背包，计算最高剑攻击力
    private float getBestSwordDamage(VillagerEntity villager) {
        try {
            Field field = villager.getClass().getDeclaredField("villagerInventory");
            field.setAccessible(true);
            SimpleInventory inv = (SimpleInventory) field.get(villager);
            float best = 0;
            for (int i = 0; i < inv.size(); i++) {
                ItemStack stack = inv.getStack(i);
                if (!stack.isEmpty() && stack.getItem() instanceof SwordItem sword) {
                    float dmg = sword.getMaterial().getAttackDamage() + 1.0F;
                    if (dmg > best) best = dmg;
                }
            }
            return best;
        } catch (NoSuchFieldException | IllegalAccessException e) {
            return 0;
        }
    }
}