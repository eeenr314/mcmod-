package com.example.villagersense.mixin;

import com.example.villagersense.VillagerSenseConfig;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.village.VillagerProfession;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(VillagerEntity.class)
public abstract class VillagerEntityTradeMixin {

    @Invoker("beginTradeWith")
    public abstract void invokeBeginTradeWith(PlayerEntity player);

    @Inject(method = "interactMob", at = @At("HEAD"), cancellable = true)
    private void allowNitwitTrade(PlayerEntity player, Hand hand, CallbackInfoReturnable<ActionResult> cir) {
        VillagerEntity self = (VillagerEntity) (Object) this;
        if (!VillagerSenseConfig.INSTANCE.enableNitwitTrading) return;
        if (!self.getVillagerData().getProfession().equals(VillagerProfession.NITWIT)) return;
        if (!self.getWorld().isClient && self.isAlive()) {
            invokeBeginTradeWith(player);
            cir.setReturnValue(ActionResult.success(self.getWorld().isClient));
        }
    }
}