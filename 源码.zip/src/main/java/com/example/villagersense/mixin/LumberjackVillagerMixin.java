package com.example.villagersense.mixin;

import com.example.villagersense.lumberjack.ai.ChopTreeGoal;
import com.example.villagersense.integration.ModuleRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.passive.MerchantEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(VillagerEntity.class)
public abstract class LumberjackVillagerMixin extends MerchantEntity {

    public LumberjackVillagerMixin(EntityType<? extends MerchantEntity> entityType, World world) {
        super(entityType, world);
    }

    @Unique
    private final SimpleInventory lumberjackInventory = new SimpleInventory(18);

    @Inject(method = "<init>", at = @At("RETURN"))
    private void onInit(CallbackInfo ci) {
        VillagerEntity self = (VillagerEntity) (Object) this;
if (!ModuleRegistry.LUMBERJACK_ENABLED) return;
        if (self.getWorld().isClient) return;
        this.goalSelector.add(3, new ChopTreeGoal(self, lumberjackInventory));
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        VillagerEntity self = (VillagerEntity) (Object) this;
        if (!self.getWorld().isClient && self.isSleeping() && self.age % 20 == 0) {
            self.heal(1.0F);
        }
    }

    @Inject(method = "onDeath", at = @At("HEAD"))
    private void onDeath(DamageSource source, CallbackInfo ci) {
        VillagerEntity self = (VillagerEntity) (Object) this;
        if (self.getWorld().isClient) return;

        for (int i = 0; i < lumberjackInventory.size(); i++) {
            ItemStack stack = lumberjackInventory.getStack(i);
            if (!stack.isEmpty()) {
                self.dropStack(stack);
            }
        }
        lumberjackInventory.clear();

        for (EquipmentSlot slot : EquipmentSlot.values()) {
            ItemStack equipped = self.getEquippedStack(slot);
            if (!equipped.isEmpty()) {
                self.dropStack(equipped);
                self.equipStack(slot, ItemStack.EMPTY);
            }
        }
    }

    @Inject(method = "writeCustomDataToNbt", at = @At("TAIL"))
    private void onWriteNbt(NbtCompound nbt, CallbackInfo ci) {
        VillagerEntity self = (VillagerEntity) (Object) this;
        NbtList list = new NbtList();
        for (int i = 0; i < lumberjackInventory.size(); i++) {
            ItemStack stack = lumberjackInventory.getStack(i);
            if (!stack.isEmpty()) {
                NbtCompound tag = new NbtCompound();
                tag.putInt("Slot", i);
                tag.put("item", stack.encode(self.getRegistryManager()));
                list.add(tag);
            }
        }
        nbt.put("LumberjackInventory", list);
    }

    @Inject(method = "readCustomDataFromNbt", at = @At("TAIL"))
    private void onReadNbt(NbtCompound nbt, CallbackInfo ci) {
        VillagerEntity self = (VillagerEntity) (Object) this;
        if (nbt.contains("LumberjackInventory")) {
            NbtList list = nbt.getList("LumberjackInventory", 10);
            for (int i = 0; i < list.size(); i++) {
                NbtCompound tag = list.getCompound(i);
                int slot = tag.getInt("Slot");
                ItemStack stack = ItemStack.fromNbt(self.getRegistryManager(), tag.get("item"))
                        .orElse(ItemStack.EMPTY);
                if (slot >= 0 && slot < lumberjackInventory.size()) {
                    lumberjackInventory.setStack(slot, stack);
                }
            }
        }
    }
}