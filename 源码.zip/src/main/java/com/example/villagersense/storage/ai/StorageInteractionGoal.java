package com.example.villagersense.storage.ai;

import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.*;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.*;

public class StorageInteractionGoal extends Goal {
    private final VillagerEntity villager;
    private final SimpleInventory villagerInventory;
    private int cooldown;

    public StorageInteractionGoal(VillagerEntity villager, SimpleInventory villagerInventory) {
        this.villager = villager;
        this.villagerInventory = villagerInventory;
        this.setControls(EnumSet.of(Control.LOOK));
        this.cooldown = 0;
    }

    @Override
    public boolean canStart() {
        if (villager.isBaby()) return false;
        if (cooldown > 0) {
            cooldown--;
            return false;
        }
        cooldown = 40;
        List<BlockPos> containers = findAllVisibleContainers();
        return !containers.isEmpty();
    }

    @Override
    public void start() {
        List<BlockPos> containers = findAllVisibleContainers();
        if (containers.isEmpty()) return;

        int idx = villager.getRandom().nextInt(containers.size());
        BlockPos targetPos = containers.get(idx);
        Inventory container = getContainerAt(targetPos);
        if (container == null) return;

        storeExcessArmor(container);
        equipBestArmor(container);
        storeExcessItems(container);
        retrieveMissingItems(container);
    }

    private List<BlockPos> findAllVisibleContainers() {
        List<BlockPos> visible = new ArrayList<>();
        World world = villager.getWorld();
        BlockPos center = villager.getBlockPos();
        Vec3d eyePos = villager.getEyePos();

        for (int x = -4; x <= 4; x++) {
            for (int y = -4; y <= 4; y++) {
                for (int z = -4; z <= 4; z++) {
                    BlockPos pos = center.add(x, y, z);
                    if (pos.getSquaredDistance(center) > 16) continue;

                    BlockEntity be = world.getBlockEntity(pos);
                    if (be instanceof Inventory) {
                        Vec3d target = Vec3d.ofCenter(pos);
                        BlockHitResult hit = world.raycast(new RaycastContext(eyePos, target,
                                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, villager));
                        if (hit.getType() == HitResult.Type.BLOCK && hit.getBlockPos().equals(pos)) {
                            visible.add(pos.toImmutable());
                        }
                    }
                }
            }
        }
        return visible;
    }

    private Inventory getContainerAt(BlockPos pos) {
        BlockEntity be = villager.getWorld().getBlockEntity(pos);
        if (be instanceof Inventory) {
            return (Inventory) be;
        }
        return null;
    }

    private void storeExcessArmor(Inventory container) {
        for (int i = 0; i < villagerInventory.size(); i++) {
            ItemStack stack = villagerInventory.getStack(i);
            if (stack.isEmpty()) continue;
            if (stack.getItem() instanceof ArmorItem) {
                ItemStack copy = stack.copy();
                if (tryAddToContainer(container, copy)) {
                    villagerInventory.setStack(i, ItemStack.EMPTY);
                }
            }
        }
    }

    private void equipBestArmor(Inventory container) {
        EquipmentSlot[] armorSlots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        for (EquipmentSlot slot : armorSlots) {
            ItemStack currentArmor = villager.getEquippedStack(slot);
            int currentScore = getArmorScore(currentArmor, slot);

            int bestScore = -1;
            int bestSlot = -1;
            for (int i = 0; i < container.size(); i++) {
                ItemStack stack = container.getStack(i);
                if (stack.isEmpty()) continue;
                if (stack.getItem() instanceof ArmorItem armor && armor.getSlotType() == slot) {
                    int score = getArmorScore(stack, slot);
                    if (score > bestScore) {
                        bestScore = score;
                        bestSlot = i;
                    }
                }
            }

            if (bestSlot >= 0 && bestScore > currentScore) {
                ItemStack newArmor = container.getStack(bestSlot).copy();
                container.setStack(bestSlot, ItemStack.EMPTY);
                if (!currentArmor.isEmpty()) {
                    tryAddToContainer(container, currentArmor.copy());
                    villager.equipStack(slot, ItemStack.EMPTY);
                }
                villager.equipStack(slot, newArmor);
            }
        }
    }

    private int getArmorScore(ItemStack stack, EquipmentSlot slot) {
        if (stack.isEmpty() || !(stack.getItem() instanceof ArmorItem armor)) return -1;
        int defense = armor.getProtection();
        float toughness = armor.getToughness();
        int durabilityPercent = (int) ((stack.getMaxDamage() - stack.getDamage()) * 9.0 / stack.getMaxDamage());
        return defense * 100 + (int)(toughness * 10) + durabilityPercent;
    }

    private void retrieveMissingItems(Inventory container) {
        Map<Item, Integer> currentCounts = getItemCounts(villagerInventory);

        for (int i = 0; i < container.size(); i++) {
            ItemStack containerStack = container.getStack(i);
            if (containerStack.isEmpty()) continue;
            Item item = containerStack.getItem();
            if (item instanceof ArmorItem) continue;
            if (!currentCounts.containsKey(item)) {
                int spaceLeft = getEmptySlots(villagerInventory);
                if (spaceLeft > 0) {
                    int toTake = Math.min(containerStack.getCount(), item.getMaxCount());
                    ItemStack taken = containerStack.copy();
                    taken.setCount(toTake);
                    if (tryAddToInventory(villagerInventory, taken)) {
                        containerStack.decrement(toTake);
                        if (containerStack.isEmpty()) {
                            container.setStack(i, ItemStack.EMPTY);
                        }
                        currentCounts.put(item, toTake);
                    }
                }
            }
        }
    }

    private void storeExcessItems(Inventory container) {
        Map<Item, Integer> counts = getItemCounts(villagerInventory);
        for (Map.Entry<Item, Integer> entry : counts.entrySet()) {
            Item item = entry.getKey();
            if (item instanceof ArmorItem) continue;
            int total = entry.getValue();
            int maxStack = item.getMaxCount();
            if (total > maxStack) {
                int excess = total - maxStack;
                for (int i = 0; i < villagerInventory.size() && excess > 0; i++) {
                    ItemStack stack = villagerInventory.getStack(i);
                    if (stack.isEmpty() || stack.getItem() != item) continue;

                    int toRemove = Math.min(excess, stack.getCount());
                    ItemStack toStore = stack.copy();
                    toStore.setCount(toRemove);
                    stack.decrement(toRemove);
                    if (stack.isEmpty()) {
                        villagerInventory.setStack(i, ItemStack.EMPTY);
                    }
                    if (tryAddToContainer(container, toStore)) {
                        excess -= toRemove;
                    } else {
                        stack.increment(toRemove);
                        excess = 0;
                    }
                }
            }
        }
    }

    private Map<Item, Integer> getItemCounts(SimpleInventory inv) {
        Map<Item, Integer> map = new HashMap<>();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack stack = inv.getStack(i);
            if (!stack.isEmpty()) {
                map.merge(stack.getItem(), stack.getCount(), Integer::sum);
            }
        }
        return map;
    }

    private boolean tryAddToInventory(SimpleInventory inv, ItemStack stack) {
        for (int i = 0; i < inv.size(); i++) {
            ItemStack slot = inv.getStack(i);
            if (slot.isEmpty()) {
                inv.setStack(i, stack);
                return true;
            } else if (ItemStack.areItemsEqual(slot, stack) && slot.getCount() < slot.getMaxCount()) {
                int transfer = Math.min(stack.getCount(), slot.getMaxCount() - slot.getCount());
                if (transfer > 0) {
                    slot.increment(transfer);
                    stack.decrement(transfer);
                    if (stack.isEmpty()) return true;
                }
            }
        }
        return stack.isEmpty();
    }

    private boolean tryAddToContainer(Inventory container, ItemStack stack) {
        for (int i = 0; i < container.size(); i++) {
            ItemStack slot = container.getStack(i);
            if (slot.isEmpty()) {
                container.setStack(i, stack);
                return true;
            } else if (ItemStack.areItemsEqual(slot, stack) && slot.getCount() < slot.getMaxCount()) {
                int transfer = Math.min(stack.getCount(), slot.getMaxCount() - slot.getCount());
                if (transfer > 0) {
                    slot.increment(transfer);
                    stack.decrement(transfer);
                    if (stack.isEmpty()) return true;
                }
            }
        }
        return false;
    }

    private int getEmptySlots(SimpleInventory inv) {
        int empty = 0;
        for (int i = 0; i < inv.size(); i++) {
            if (inv.getStack(i).isEmpty()) empty++;
        }
        return empty;
    }
}