package com.example.villagerapi;

import net.minecraft.util.math.BlockPos;

public interface Rallyable {
    BlockPos getRallyPoint();
    void setRallyPoint(BlockPos pos);
    void clearRallyPoint();
    void tickRallyPoint();
}